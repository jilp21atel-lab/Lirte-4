import { useState, useEffect } from "react";
import { Project, PosterVariation } from "./types";
import { Splash } from "./components/Splash";
import { Welcome } from "./components/Welcome";
import { Dashboard } from "./components/Dashboard";
import { ChatWorkspace } from "./components/ChatWorkspace";
import { AnimatePresence, motion } from "motion/react";

// Initialize a beautiful default Fintech Wise-inspired project for instant premium onboarding
const INITIAL_DEMO_PROJECTS: Project[] = [
  {
    id: "demo-wise-fintech",
    name: "Wise Premium Ad",
    category: "Finance",
    prompt: "Design a premium Wise-inspired forest green and lime advertisement poster with active charts and clean typography.",
    themeStyle: "Minimalist Editorial",
    createdAt: new Date().toISOString(),
    selectedPosterIndex: 0,
    posters: [
      {
        layoutType: "minimal-editorial",
        title: "FINANCE, ELEVATED IN SECONDS.",
        subtitle: "Send money globally with ultra-low transparent fees, complete with automatic smart-budget trackers and high-yield interest nodes.",
        badgeText: "★ APP OF THE WEEK",
        colors: {
          bgGradientType: "linear",
          bgColors: ["#163300", "#0B1500"], // Forest brand colors
          accentColor: "#9FE870", // Lime accent
          textColor: "#FFFFFF",
          textMutedColor: "#C3D2B8"
        },
        features: [
          { iconName: "Wallet", title: "Transparent Fees", desc: "Save up to 8x compared to standard high-street banks." },
          { iconName: "TrendingUp", title: "Yield Assets", desc: "Watch your balance scale automatically with total protection." }
        ],
        appUI: {
          screenTitle: "Performance Nodes",
          screenBalance: "99.8% Optimal",
          chartData: [20, 35, 25, 60, 45, 80, 100],
          theme: "dark",
          items: [
            { label: "Active Node", value: "Live ✓", icon: "Check", color: "#9FE870" },
            { label: "Pipeline Feed", value: "Instant", icon: "Activity", color: "#9FE870" }
          ]
        },
        promptDescription: "A minimalist wise-inspired dark forest theme centering on bold Space Grotesk display headings, ample whitespace, and vivid lime accents."
      },
      {
        layoutType: "hero-showcase",
        title: "TAKE ABSOLUTE CONTROL.",
        subtitle: "Redefining gold standards of global asset transfers with transparent currency tables and premium vector metrics.",
        badgeText: "RATED 4.9★ BY EDITORS",
        colors: {
          bgGradientType: "radial",
          bgColors: ["#0E0F0C", "#262B24", "#121411"],
          accentColor: "#F59E0B", // Amber accent
          textColor: "#FFFFFF",
          textMutedColor: "#9CA3AF"
        },
        features: [
          { iconName: "Shield", title: "Secured Safes", desc: "Vault locks automatically guarded by biometric keys." },
          { iconName: "Zap", title: "Direct Transfers", desc: "Send, receive, and trade 40+ currencies instantly." }
        ],
        appUI: {
          screenTitle: "Total Balance",
          screenBalance: "$24,510.50",
          chartData: [40, 20, 60, 45, 80, 70, 95],
          theme: "dark",
          items: [
            { label: "Weekly Growth", value: "+12.4%", icon: "TrendingUp", color: "#10B981" },
            { label: "Biometrics", value: "Enabled", icon: "Shield", color: "#F59E0B" }
          ]
        },
        promptDescription: "A luxurious deep charcoal editorial theme focusing on sleek metallic mockups, sharp details, and warm gold sparks."
      }
    ]
  }
];

export default function App() {
  const [currentView, setCurrentView] = useState<"splash" | "welcome" | "dashboard" | "workspace">("splash");
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Load projects from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem("app4_projects");
      if (stored) {
        setProjects(JSON.parse(stored));
      } else {
        // First load gets the demo Wise project!
        setProjects(INITIAL_DEMO_PROJECTS);
        localStorage.setItem("app4_projects", JSON.stringify(INITIAL_DEMO_PROJECTS));
      }
    } catch (e) {
      console.warn("Could not read local storage projects:", e);
      setProjects(INITIAL_DEMO_PROJECTS);
    }
  }, []);

  // Sync projects to localStorage
  const saveProjects = (updatedProjects: Project[]) => {
    setProjects(updatedProjects);
    try {
      localStorage.setItem("app4_projects", JSON.stringify(updatedProjects));
    } catch (e) {
      console.warn("Could not save projects to local storage:", e);
    }
  };

  // Create a new empty design project with default blank states
  const handleNewProject = (name: string, category: string, themeStyle: string) => {
    // Generate beautiful initial layouts based on selected theme preference style
    const isCyber = themeStyle.toLowerCase().includes("cyber");
    const isGradient = themeStyle.toLowerCase().includes("gradient");
    const isGlass = themeStyle.toLowerCase().includes("glass");
    
    const initialPoster: PosterVariation = {
      layoutType: "hero-showcase",
      title: `${name.toUpperCase()}: THE FUTURE IS HERE.`,
      subtitle: `Experience the advanced ${category.toLowerCase()} capabilities of ${name}, designed with gorgeous visual grids and metric dashboards.`,
      badgeText: "PRE-RELEASE v1.0",
      colors: isCyber ? {
        bgGradientType: "linear",
        bgColors: ["#0B0D19", "#04050A"],
        accentColor: "#EC4899", // Neon Pink
        textColor: "#FFFFFF",
        textMutedColor: "#94A3B8"
      } : isGradient ? {
        bgGradientType: "linear",
        bgColors: ["#0B1500", "#1B3B06", "#0B1500"], // Forest theme
        accentColor: "#9FE870", // Lime
        textColor: "#FFFFFF",
        textMutedColor: "#C3D2B8"
      } : {
        bgGradientType: "linear",
        bgColors: ["#0E0F0C", "#1F231D"],
        accentColor: "#F59E0B", // Amber
        textColor: "#FFFFFF",
        textMutedColor: "#9CA3AF"
      },
      features: [
        { iconName: "Zap", title: "Instant Velocity", desc: "No lags, optimal operational response speeds." },
        { iconName: "Shield", title: "Total Protection", desc: "Decentralized logs keep your performance secure." }
      ],
      appUI: {
        screenTitle: "Pipeline Metrics",
        screenBalance: "99.8% Verified",
        chartData: [10, 45, 30, 75, 50, 90, 100],
        theme: "dark",
        items: [
          { label: "Active Feed", value: "Online", icon: "Activity", color: isCyber ? "#EC4899" : "#9FE870" },
          { label: "System Nodes", value: "Secure", icon: "Check", color: isCyber ? "#EC4899" : "#9FE870" }
        ]
      },
      promptDescription: "A starter setup constructed automatically to jumpstart your prompt journey."
    };

    const newProj: Project = {
      id: `proj-${Date.now()}`,
      name,
      category,
      prompt: `Initial concept for ${name} under category ${category}`,
      themeStyle,
      createdAt: new Date().toISOString(),
      posters: [initialPoster],
      selectedPosterIndex: 0
    };

    const updated = [newProj, ...projects];
    saveProjects(updated);
    setSelectedProject(newProj);
    setCurrentView("workspace");
  };

  const handleUpdateProject = (updated: Project) => {
    const list = projects.map(p => p.id === updated.id ? updated : p);
    saveProjects(list);
    setSelectedProject(updated);
  };

  const handleSelectProject = (project: Project) => {
    setSelectedProject(project);
    setCurrentView("workspace");
  };

  const handleWelcomeComplete = (asGuest: boolean) => {
    // If user clicked SignIn or Guest, open Dashboard cleanly
    setCurrentView("dashboard");
  };

  return (
    <div className="w-full h-full min-h-screen bg-white text-brand-charcoal overflow-hidden font-sans relative">
      <AnimatePresence mode="wait">
        
        {/* VIEW 1: Premium Loading Splash */}
        {currentView === "splash" && (
          <motion.div 
            key="splash" 
            className="absolute inset-0"
            exit={{ opacity: 0 }}
          >
            <Splash onComplete={() => setCurrentView("welcome")} />
          </motion.div>
        )}

        {/* VIEW 2: Brand Welcome Hero Screen */}
        {currentView === "welcome" && (
          <motion.div
            key="welcome"
            className="w-full min-h-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Welcome onContinue={handleWelcomeComplete} />
          </motion.div>
        )}

        {/* VIEW 3: Dashboard Registry list */}
        {currentView === "dashboard" && (
          <motion.div
            key="dashboard"
            className="w-full min-h-screen"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
          >
            <Dashboard 
              projects={projects}
              onSelectProject={handleSelectProject}
              onNewProject={handleNewProject}
            />
          </motion.div>
        )}

        {/* VIEW 4: Core Three-Panel Poster Workspace Room */}
        {currentView === "workspace" && selectedProject && (
          <motion.div
            key="workspace"
            className="w-full h-screen"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <ChatWorkspace 
              project={selectedProject}
              onBack={() => {
                setSelectedProject(null);
                setCurrentView("dashboard");
              }}
              onUpdateProject={handleUpdateProject}
            />
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
