import { PosterVariation } from "../types";

export interface ExportConfig {
  format: "png" | "jpeg" | "webp";
  ratio: "story" | "square" | "ultra" | "appstore" | "banner";
  quality: "standard" | "hd" | "4k";
  deviceFrame: "none" | "black" | "white" | "titanium";
  shadowOn: boolean;
  reflectionOn: boolean;
}

// Map ratio & quality to exact pixel dimensions
export function getDimensions(ratio: string, quality: string): { width: number; height: number } {
  let scale = 1;
  if (quality === "hd") scale = 1.5;
  if (quality === "4k") scale = 3;

  switch (ratio) {
    case "square":
      return { width: Math.round(1080 * scale), height: Math.round(1080 * scale) };
    case "banner":
      return { width: Math.round(1920 * (scale > 1.5 ? 1.5 : scale)), height: Math.round(1080 * (scale > 1.5 ? 1.5 : scale)) };
    case "appstore":
      return { width: Math.round(1242 * (scale > 1.5 ? 1.5 : scale)), height: Math.round(2208 * (scale > 1.5 ? 1.5 : scale)) };
    case "story":
    case "ultra":
    default:
      if (quality === "4k") {
        return { width: 2160, height: 3840 }; // Standard 4K 9:16
      }
      return { width: Math.round(1080 * scale), height: Math.round(1920 * scale) };
  }
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number
): number {
  const words = text.split(" ");
  let line = "";
  let lineCount = 0;
  
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + " ";
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    
    if (testWidth > maxWidth && n > 0) {
      ctx.fillText(line.trim(), x, y + lineCount * lineHeight);
      line = words[n] + " ";
      lineCount++;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, y + lineCount * lineHeight);
  return (lineCount + 1) * lineHeight;
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.referrerPolicy = "no-referrer";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Failed to load image " + src));
    img.src = src;
  });
}

export async function exportPosterToImage(
  poster: PosterVariation,
  config: ExportConfig
): Promise<string> {
  const { width, height } = getDimensions(config.ratio, config.quality);
  
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  
  if (!ctx) {
    throw new Error("Could not get canvas context.");
  }

  // Pre-load the active custom generated graphics background if it exists
  let loadedImage: HTMLImageElement | null = null;
  if (poster.appUI.generatedImage) {
    try {
      loadedImage = await loadImage(poster.appUI.generatedImage);
    } catch (err) {
      console.warn("Failed to load custom generated image for canvas render, using fallback.", err);
    }
  }

  // --- SPECIALIZED LANDSCAPE BANNER LAYOUT (16:9) ---
  if (config.ratio === "banner") {
    const s = height / 1080; // Scale relative to 1080px base height
    const colors = poster.colors;

    // 1. Draw Background Gradient
    if (colors.bgGradientType === "radial") {
      const gradient = ctx.createRadialGradient(width / 2, height / 2, 50 * s, width / 2, height / 2, width * 0.8);
      gradient.addColorStop(0, colors.bgColors[0]);
      gradient.addColorStop(1, colors.bgColors[colors.bgColors.length - 1]);
      ctx.fillStyle = gradient;
    } else {
      const gradient = ctx.createLinearGradient(0, 0, width, height);
      colors.bgColors.forEach((color, idx) => {
        gradient.addColorStop(idx / (colors.bgColors.length - 1), color);
      });
      ctx.fillStyle = gradient;
    }
    ctx.fillRect(0, 0, width, height);

    // 2. Subtle Dots Grid
    ctx.fillStyle = "rgba(255, 255, 255, 0.04)";
    const dotSpacing = 48 * s;
    for (let x = 0; x < width; x += dotSpacing) {
      for (let y = 0; y < height; y += dotSpacing) {
        ctx.beginPath();
        ctx.arc(x, y, 2 * s, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 3. Right-Aligned Accent Ambient Glow
    const glowRad = 600 * s;
    const radGlow = ctx.createRadialGradient(width * 0.75, height / 2, 10 * s, width * 0.75, height / 2, glowRad);
    radGlow.addColorStop(0, `${colors.accentColor}35`);
    radGlow.addColorStop(1, "transparent");
    ctx.fillStyle = radGlow;
    ctx.beginPath();
    ctx.arc(width * 0.75, height / 2, glowRad, 0, Math.PI * 2);
    ctx.fill();

    // 4. Draw Header Badge on the left
    ctx.save();
    ctx.fillStyle = colors.accentColor;
    ctx.font = `bold ${Math.round(22 * s)}px "Inter", sans-serif`;
    ctx.textBaseline = "middle";
    ctx.textAlign = "left";

    const badgeText = poster.badgeText.toUpperCase();
    const badgeWidth = ctx.measureText(badgeText).width + 40 * s;
    const badgeHeight = 48 * s;
    const badgeX = 100 * s;
    const badgeY = 120 * s;

    ctx.strokeStyle = `${colors.accentColor}40`;
    ctx.lineWidth = 2 * s;
    ctx.fillStyle = "rgba(0, 0, 0, 0.25)";
    ctx.beginPath();
    ctx.roundRect(badgeX, badgeY, badgeWidth, badgeHeight, 999 * s);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = colors.accentColor;
    ctx.fillText(badgeText, badgeX + 20 * s, badgeY + badgeHeight / 2);
    ctx.restore();

    // 5. Draw Title on Left (Wrapped beautifully)
    ctx.save();
    ctx.fillStyle = colors.textColor;
    ctx.font = `900 ${Math.round(64 * s)}px "Space Grotesk", sans-serif`;
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    
    const titleX = 100 * s;
    const titleY = 195 * s;
    const maxTitleWidth = width * 0.5 - 100 * s;
    const titleLineHeight = 78 * s;
    const titleHeight = wrapText(ctx, poster.title.toUpperCase(), titleX, titleY, maxTitleWidth, titleLineHeight);
    ctx.restore();

    // 6. Draw Subtitle / Slogan on Left
    ctx.save();
    ctx.fillStyle = colors.textMutedColor;
    ctx.font = `400 ${Math.round(24 * s)}px "Inter", sans-serif`;
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    
    const subtitleY = titleY + titleHeight + 24 * s;
    const subLineHeight = 38 * s;
    const subtitleHeight = wrapText(ctx, poster.subtitle, titleX, subtitleY, maxTitleWidth, subLineHeight);
    ctx.restore();

    // 7. Draw Features Stacked/Grid horizontally on the bottom left
    const footerY = subtitleY + subtitleHeight + 48 * s;
    ctx.save();
    const featureColWidth = (maxTitleWidth - 40 * s) / 2;
    poster.features.forEach((feat, idx) => {
      const fX = 100 * s + idx * (featureColWidth + 40 * s);
      const fY = footerY;

      // Icon Rounded Box
      ctx.fillStyle = colors.accentColor;
      ctx.beginPath();
      ctx.roundRect(fX, fY, 56 * s, 56 * s, 16 * s);
      ctx.fill();

      // Flat star/icon indicator path
      ctx.fillStyle = "#000000";
      ctx.beginPath();
      ctx.arc(fX + 28 * s, fY + 28 * s, 10 * s, 0, Math.PI * 2);
      ctx.fill();

      // Feature Title
      ctx.fillStyle = colors.textColor;
      ctx.font = `bold ${Math.round(20 * s)}px "Space Grotesk", sans-serif`;
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      ctx.fillText(feat.title.toUpperCase(), fX + 72 * s, fY);

      // Feature Description
      ctx.fillStyle = colors.textMutedColor;
      ctx.font = `400 ${Math.round(15 * s)}px "Inter", sans-serif`;
      wrapText(ctx, feat.desc, fX + 72 * s, fY + 28 * s, featureColWidth - 80 * s, 22 * s);
    });
    ctx.restore();

    // 8. Draw Gorgeous Right-Floating Mobile Mockup (Scaled)
    const phoneWidth = 480 * s;
    const phoneHeight = 780 * s;
    const phoneX = width * 0.74 - phoneWidth / 2;
    const appUIParentY = height / 2 - phoneHeight / 2;

    ctx.save();
    const appUI = poster.appUI;
    const isDarkAppTheme = appUI.theme === "dark" || loadedImage !== null;

    if (config.shadowOn) {
      ctx.shadowColor = "rgba(0,0,0,0.55)";
      ctx.shadowBlur = 48 * s;
      ctx.shadowOffsetY = 16 * s;
    }

    // Clip image if custom background generated
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(phoneX, appUIParentY, phoneWidth, phoneHeight, 72 * s);
    ctx.clip();

    if (loadedImage) {
      ctx.drawImage(loadedImage, phoneX, appUIParentY, phoneWidth, phoneHeight);
      ctx.fillStyle = "rgba(0, 0, 0, 0.45)";
      ctx.fillRect(phoneX, appUIParentY, phoneWidth, phoneHeight);
    } else {
      ctx.fillStyle = isDarkAppTheme ? "#0A0D10" : "#FFFFFF";
      ctx.fill();
    }
    ctx.restore();
    ctx.shadowColor = "transparent"; // Reset shadow

    // Phone bezel stroke
    ctx.strokeStyle = isDarkAppTheme ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)";
    ctx.lineWidth = 3.5 * s;
    ctx.beginPath();
    ctx.roundRect(phoneX, appUIParentY, phoneWidth, phoneHeight, 72 * s);
    ctx.stroke();

    // Speaker Notch (Dynamic Island)
    ctx.fillStyle = "#000000";
    const notchWidth = 150 * s;
    const notchHeight = 30 * s;
    ctx.beginPath();
    ctx.roundRect(width * 0.74 - notchWidth / 2, appUIParentY + 12 * s, notchWidth, notchHeight, 999 * s);
    ctx.fill();

    // Status Bar text
    ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
    ctx.font = `bold ${Math.round(16 * s)}px "JetBrains Mono", sans-serif`;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.globalAlpha = 0.6;
    ctx.fillText("09:41", phoneX + 40 * s, appUIParentY + 28 * s);

    // Status battery icon
    ctx.lineWidth = 1.8 * s;
    ctx.strokeStyle = ctx.fillStyle;
    ctx.beginPath();
    ctx.roundRect(phoneX + phoneWidth - 76 * s, appUIParentY + 20 * s, 32 * s, 15 * s, 3 * s);
    ctx.stroke();
    ctx.fillStyle = ctx.strokeStyle;
    ctx.globalAlpha = 1.0;
    ctx.fillRect(phoneX + phoneWidth - 72 * s, appUIParentY + 23 * s, 21 * s, 9 * s);

    // Screen Header
    ctx.globalAlpha = 0.6;
    ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#454745";
    ctx.font = `600 ${Math.round(14 * s)}px "Inter", sans-serif`;
    ctx.fillText("TOTAL PERFORMANCE", phoneX + 32 * s, appUIParentY + 90 * s);
    
    ctx.globalAlpha = 1.0;
    ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
    ctx.font = `bold ${Math.round(22 * s)}px "Inter", sans-serif`;
    ctx.fillText(appUI.screenTitle, phoneX + 32 * s, appUIParentY + 118 * s);

    // Top Right Sparkle
    ctx.fillStyle = colors.accentColor;
    ctx.beginPath();
    ctx.arc(phoneX + phoneWidth - 44 * s, appUIParentY + 104 * s, 12 * s, 0, Math.PI * 2);
    ctx.fill();

    // Metrics screen balance
    ctx.fillStyle = loadedImage ? "#FFFFFF" : colors.accentColor;
    ctx.font = `900 ${Math.round(40 * s)}px "Space Grotesk", sans-serif`;
    ctx.fillText(appUI.screenBalance, phoneX + 32 * s, appUIParentY + 180 * s);

    // Sparkline Graph (Render only if NOT showing loadedImage backdrop to keep design clean)
    const chartY = appUIParentY + 230 * s;
    const chartHeight = 180 * s;
    const chartWidth = phoneWidth - 64 * s;
    const chartX = phoneX + 32 * s;

    if (!loadedImage && appUI.chartData && appUI.chartData.length > 1) {
      ctx.save();
      const chartGlow = ctx.createLinearGradient(0, chartY, 0, chartY + chartHeight);
      chartGlow.addColorStop(0, `${colors.accentColor}55`);
      chartGlow.addColorStop(1, `${colors.accentColor}00`);
      ctx.fillStyle = chartGlow;

      ctx.beginPath();
      ctx.moveTo(chartX, chartY + chartHeight);
      appUI.chartData.forEach((val, idx) => {
        const stepX = chartX + idx * (chartWidth / (appUI.chartData.length - 1));
        const stepY = chartY + chartHeight - (val / 100) * (chartHeight * 0.8);
        ctx.lineTo(stepX, stepY);
      });
      ctx.lineTo(chartX + chartWidth, chartY + chartHeight);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = colors.accentColor;
      ctx.lineWidth = 4.5 * s;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.beginPath();
      appUI.chartData.forEach((val, idx) => {
        const stepX = chartX + idx * (chartWidth / (appUI.chartData.length - 1));
        const stepY = chartY + chartHeight - (val / 100) * (chartHeight * 0.8);
        if (idx === 0) ctx.moveTo(stepX, stepY);
        else ctx.lineTo(stepX, stepY);
      });
      ctx.stroke();
      ctx.restore();
    } else if (loadedImage) {
      // Dynamic flat badge indicator
      ctx.fillStyle = "rgba(159, 232, 112, 0.15)";
      ctx.strokeStyle = "rgba(159, 232, 112, 0.4)";
      ctx.lineWidth = 1 * s;
      ctx.beginPath();
      ctx.roundRect(chartX, chartY + 30 * s, chartWidth, 100 * s, 16 * s);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = "#9FE870";
      ctx.font = `bold ${Math.round(14 * s)}px "JetBrains Mono", sans-serif`;
      ctx.textAlign = "center";
      ctx.fillText("★ NENO CUSTOM GRAPHICS ENGINE ACTIVE", chartX + chartWidth / 2, chartY + 80 * s);
    }

    // Render Transaction Row items inside mockup screen
    const rowStartY = chartY + chartHeight + 32 * s;
    appUI.items.slice(0, loadedImage ? 1 : 2).forEach((item, idx) => {
      const rowY = rowStartY + idx * (98 * s);
      const rowHeight = 78 * s;
      const rowW = phoneWidth - 64 * s;
      const rowX = phoneX + 32 * s;

      ctx.fillStyle = isDarkAppTheme ? "rgba(255,255,255,0.05)" : "rgba(0,0,0,0.04)";
      ctx.beginPath();
      ctx.roundRect(rowX, rowY, rowW, rowHeight, 20 * s);
      ctx.fill();

      // Row Icon circular backdrop
      ctx.fillStyle = item.color || colors.accentColor;
      ctx.beginPath();
      ctx.arc(rowX + 42 * s, rowY + rowHeight / 2, 18 * s, 0, Math.PI * 2);
      ctx.fill();

      // Row description label
      ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
      ctx.font = `600 ${Math.round(16 * s)}px "Inter", sans-serif`;
      ctx.textAlign = "left";
      ctx.fillText(item.label, rowX + 76 * s, rowY + rowHeight / 2);

      // Row value amount
      ctx.fillStyle = loadedImage ? "#9FE870" : (item.color || colors.accentColor);
      ctx.font = `bold ${Math.round(16 * s)}px "JetBrains Mono", sans-serif`;
      ctx.textAlign = "right";
      ctx.fillText(item.value, rowX + rowW - 24 * s, rowY + rowHeight / 2);
    });

    // Home indicator line
    ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
    ctx.globalAlpha = 0.2;
    ctx.beginPath();
    ctx.roundRect(width * 0.74 - 60 * s, appUIParentY + phoneHeight - 16 * s, 120 * s, 5 * s, 999 * s);
    ctx.fill();
    ctx.restore();

    // Export as selected image format
    const mimeType = config.format === "jpeg" ? "image/jpeg" : config.format === "webp" ? "image/webp" : "image/png";
    return canvas.toDataURL(mimeType, 0.95);
  }

  // --- STANDARD PORTRAIT DESIGNS (Story, Square, AppStore Promo) ---
  const sX = width / 1080;
  const sY = height / 1920;
  const s = Math.min(sX, sY);

  // 1. Draw Background Gradient
  const colors = poster.colors;
  if (poster.colors.bgGradientType === "radial") {
    const gradient = ctx.createRadialGradient(width / 2, height / 2, 50 * s, width / 2, height / 2, width * 0.8);
    gradient.addColorStop(0, colors.bgColors[0]);
    gradient.addColorStop(1, colors.bgColors[colors.bgColors.length - 1]);
    ctx.fillStyle = gradient;
  } else {
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    colors.bgColors.forEach((color, idx) => {
      gradient.addColorStop(idx / (colors.bgColors.length - 1), color);
    });
    ctx.fillStyle = gradient;
  }
  ctx.fillRect(0, 0, width, height);

  // 2. Draw Subtle Dots Grid
  ctx.fillStyle = "rgba(255, 255, 255, 0.04)";
  const dotSpacing = 48 * s;
  for (let x = 0; x < width; x += dotSpacing) {
    for (let y = 0; y < height; y += dotSpacing) {
      ctx.beginPath();
      ctx.arc(x, y, 2 * s, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // 3. Draw Ambient Glows
  const glowRad = 400 * s;
  const radGlow = ctx.createRadialGradient(width, height, 10 * s, width, height, glowRad);
  radGlow.addColorStop(0, `${colors.accentColor}25`);
  radGlow.addColorStop(1, "transparent");
  ctx.fillStyle = radGlow;
  ctx.beginPath();
  ctx.arc(width, height, glowRad, 0, Math.PI * 2);
  ctx.fill();

  // 4. Draw Header Badge text
  ctx.save();
  ctx.fillStyle = colors.accentColor;
  ctx.font = `bold ${Math.round(26 * s)}px "Inter", sans-serif`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";

  // Badge background pill
  const badgeText = poster.badgeText.toUpperCase();
  const badgeWidth = ctx.measureText(badgeText).width + 48 * s;
  const badgeHeight = 56 * s;
  const badgeX = width / 2 - badgeWidth / 2;
  const badgeY = 120 * s;

  ctx.strokeStyle = `${colors.accentColor}40`;
  ctx.lineWidth = 2 * s;
  ctx.fillStyle = "rgba(0, 0, 0, 0.2)";
  
  // Draw rounded pill
  ctx.beginPath();
  ctx.roundRect(badgeX, badgeY, badgeWidth, badgeHeight, 9999 * s);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = colors.accentColor;
  ctx.fillText(badgeText, width / 2, badgeY + badgeHeight / 2);
  ctx.restore();

  // 5. Draw Headline / Title
  ctx.save();
  ctx.fillStyle = colors.textColor;
  ctx.font = `900 ${Math.round(68 * s)}px "Space Grotesk", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  
  const titleY = 220 * s;
  const maxTitleWidth = width - 160 * s;
  const titleLineHeight = 84 * s;
  
  const titleHeight = wrapText(ctx, poster.title.toUpperCase(), width / 2, titleY, maxTitleWidth, titleLineHeight);
  ctx.restore();

  // 6. Draw Subtitle / Description
  ctx.save();
  ctx.fillStyle = colors.textMutedColor;
  ctx.font = `400 ${Math.round(28 * s)}px "Inter", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  
  const subtitleY = titleY + titleHeight + 20 * s;
  const maxSubWidth = width - 240 * s;
  const subLineHeight = 42 * s;
  
  const subtitleHeight = wrapText(ctx, poster.subtitle, width / 2, subtitleY, maxSubWidth, subLineHeight);
  ctx.restore();

  // 7. Draw Simulated Mobile Screen (Center)
  const appUIParentY = subtitleY + subtitleHeight + 40 * s;
  const phoneWidth = 560 * s;
  const phoneHeight = 900 * s;
  const phoneX = width / 2 - phoneWidth / 2;

  // Let's paint the App UI inside the phone area!
  ctx.save();
  const appUI = poster.appUI;
  const isDarkAppTheme = appUI.theme === "dark" || loadedImage !== null;

  // Draw phone frame/container shadow if requested
  if (config.shadowOn) {
    ctx.shadowColor = "rgba(0,0,0,0.5)";
    ctx.shadowBlur = 50 * s;
    ctx.shadowOffsetY = 20 * s;
  }

  // Draw background image if loaded, else fallback color
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(phoneX, appUIParentY, phoneWidth, phoneHeight, 80 * s);
  ctx.clip();

  if (loadedImage) {
    ctx.drawImage(loadedImage, phoneX, appUIParentY, phoneWidth, phoneHeight);
    ctx.fillStyle = "rgba(0, 0, 0, 0.45)";
    ctx.fillRect(phoneX, appUIParentY, phoneWidth, phoneHeight);
  } else {
    ctx.fillStyle = isDarkAppTheme ? "#0A0D10" : "#FFFFFF";
    ctx.fill();
  }
  ctx.restore();
  ctx.shadowColor = "transparent"; // Reset shadow

  // Thin screen border border
  ctx.strokeStyle = isDarkAppTheme ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)";
  ctx.lineWidth = 3 * s;
  ctx.beginPath();
  ctx.roundRect(phoneX, appUIParentY, phoneWidth, phoneHeight, 80 * s);
  ctx.stroke();

  // Speaker Notch (Dynamic Island)
  ctx.fillStyle = "#000000";
  const notchWidth = 180 * s;
  const notchHeight = 36 * s;
  ctx.beginPath();
  ctx.roundRect(width / 2 - notchWidth / 2, appUIParentY + 12 * s, notchWidth, notchHeight, 9999 * s);
  ctx.fill();

  // Status Bar texts
  ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
  ctx.font = `bold ${Math.round(20 * s)}px "JetBrains Mono", sans-serif`;
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.globalAlpha = 0.6;
  ctx.fillText("09:41", phoneX + 48 * s, appUIParentY + 30 * s);

  // Status icons (battery, wifi outline)
  ctx.lineWidth = 2 * s;
  ctx.strokeStyle = ctx.fillStyle;
  ctx.beginPath();
  ctx.roundRect(phoneX + phoneWidth - 88 * s, appUIParentY + 22 * s, 40 * s, 18 * s, 4 * s);
  ctx.stroke();
  ctx.fillStyle = ctx.strokeStyle;
  ctx.globalAlpha = 1.0;
  ctx.fillRect(phoneX + phoneWidth - 84 * s, appUIParentY + 25 * s, 26 * s, 12 * s);

  // Screen Header title
  ctx.globalAlpha = 0.6;
  ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#454745";
  ctx.font = `600 ${Math.round(18 * s)}px "Inter", sans-serif`;
  ctx.fillText("TOTAL PERFORMANCE", phoneX + 40 * s, appUIParentY + 100 * s);
  
  ctx.globalAlpha = 1.0;
  ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
  ctx.font = `bold ${Math.round(28 * s)}px "Inter", sans-serif`;
  ctx.fillText(appUI.screenTitle, phoneX + 40 * s, appUIParentY + 135 * s);

  // Sparkle Icon beside header
  ctx.fillStyle = colors.accentColor;
  ctx.beginPath();
  ctx.arc(phoneX + phoneWidth - 56 * s, appUIParentY + 115 * s, 16 * s, 0, Math.PI * 2);
  ctx.fill();

  // Screen Main Value / Balance
  ctx.fillStyle = loadedImage ? "#FFFFFF" : colors.accentColor;
  ctx.font = `900 ${Math.round(52 * s)}px "Space Grotesk", sans-serif`;
  ctx.fillText(appUI.screenBalance, phoneX + 40 * s, appUIParentY + 210 * s);

  // Draw chart inside phone screen
  const chartY = appUIParentY + 280 * s;
  const chartHeight = 220 * s;
  const chartWidth = phoneWidth - 80 * s;
  const chartX = phoneX + 40 * s;

  if (!loadedImage && appUI.chartData && appUI.chartData.length > 1) {
    ctx.save();
    // Fill background glow
    const chartGlow = ctx.createLinearGradient(0, chartY, 0, chartY + chartHeight);
    chartGlow.addColorStop(0, `${colors.accentColor}60`);
    chartGlow.addColorStop(1, `${colors.accentColor}00`);
    ctx.fillStyle = chartGlow;

    ctx.beginPath();
    ctx.moveTo(chartX, chartY + chartHeight);

    appUI.chartData.forEach((val, idx) => {
      const stepX = chartX + idx * (chartWidth / (appUI.chartData.length - 1));
      const stepY = chartY + chartHeight - (val / 100) * (chartHeight * 0.8);
      ctx.lineTo(stepX, stepY);
    });

    ctx.lineTo(chartX + chartWidth, chartY + chartHeight);
    ctx.closePath();
    ctx.fill();

    // Stroke line
    ctx.strokeStyle = colors.accentColor;
    ctx.lineWidth = 6 * s;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    
    appUI.chartData.forEach((val, idx) => {
      const stepX = chartX + idx * (chartWidth / (appUI.chartData.length - 1));
      const stepY = chartY + chartHeight - (val / 100) * (chartHeight * 0.8);
      if (idx === 0) {
        ctx.moveTo(stepX, stepY);
      } else {
        ctx.lineTo(stepX, stepY);
      }
    });
    ctx.stroke();
    ctx.restore();
  } else if (loadedImage) {
    // Elegant floating vector art details badge
    ctx.fillStyle = "rgba(159, 232, 112, 0.15)";
    ctx.strokeStyle = "rgba(159, 232, 112, 0.4)";
    ctx.lineWidth = 1.5 * s;
    ctx.beginPath();
    ctx.roundRect(chartX, chartY + 24 * s, chartWidth, 140 * s, 18 * s);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = "#9FE870";
    ctx.font = `bold ${Math.round(16 * s)}px "JetBrains Mono", sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText("★ NENO AI VECTOR GRAPHICS MODULE ACTIVE", chartX + chartWidth / 2, chartY + 100 * s);
  }

  // Draw transaction rows inside phone
  const rowStartY = chartY + chartHeight + 40 * s;
  appUI.items.slice(0, loadedImage ? 1 : 2).forEach((item, idx) => {
    const rowY = rowStartY + idx * (120 * s);
    const rowHeight = 96 * s;
    const rowX = phoneX + 40 * s;
    const rowW = phoneWidth - 80 * s;

    // Draw row background pill
    ctx.fillStyle = isDarkAppTheme ? "rgba(255,255,255,0.04)" : "rgba(0,0,0,0.04)";
    ctx.beginPath();
    ctx.roundRect(rowX, rowY, rowW, rowHeight, 28 * s);
    ctx.fill();

    // Draw row icon circle
    ctx.fillStyle = item.color || colors.accentColor;
    ctx.beginPath();
    ctx.arc(rowX + 54 * s, rowY + rowHeight / 2, 24 * s, 0, Math.PI * 2);
    ctx.fill();

    // Row label text
    ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
    ctx.font = `600 ${Math.round(22 * s)}px "Inter", sans-serif`;
    ctx.textAlign = "left";
    ctx.fillText(item.label, rowX + 104 * s, rowY + rowHeight / 2);

    // Row value text
    ctx.fillStyle = loadedImage ? "#9FE870" : (item.color || colors.accentColor);
    ctx.font = `bold ${Math.round(22 * s)}px "JetBrains Mono", sans-serif`;
    ctx.textAlign = "right";
    ctx.fillText(item.value, rowX + rowW - 32 * s, rowY + rowHeight / 2);
  });

  // Home Indicator line
  ctx.fillStyle = isDarkAppTheme ? "#FFFFFF" : "#000000";
  ctx.globalAlpha = 0.2;
  ctx.beginPath();
  ctx.roundRect(width / 2 - 80 * s, appUIParentY + phoneHeight - 20 * s, 160 * s, 8 * s, 999 * s);
  ctx.fill();
  ctx.restore();

  // 8. Draw Features/Highlights (Bottom Footer)
  const footerY = appUIParentY + phoneHeight + 40 * s;
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.08)";
  ctx.lineWidth = 1 * s;
  ctx.beginPath();
  ctx.moveTo(80 * s, footerY);
  ctx.lineTo(width - 80 * s, footerY);
  ctx.stroke();

  const featureColWidth = (width - 240 * s) / 2;
  poster.features.forEach((feat, idx) => {
    const fX = 100 * s + idx * (featureColWidth + 40 * s);
    const fY = footerY + 24 * s;

    // Draw feature icon circle
    ctx.fillStyle = colors.accentColor;
    ctx.beginPath();
    ctx.roundRect(fX, fY, 68 * s, 68 * s, 20 * s);
    ctx.fill();

    // Draw clean icon shapes (simple vector paths so we have no image-load dependencies!)
    ctx.fillStyle = "#000000";
    ctx.beginPath();
    ctx.arc(fX + 34 * s, fY + 34 * s, 14 * s, 0, Math.PI * 2);
    ctx.fill();

    // Feature Title
    ctx.fillStyle = colors.textColor;
    ctx.font = `bold ${Math.round(24 * s)}px "Space Grotesk", sans-serif`;
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillText(feat.title.toUpperCase(), fX + 90 * s, fY);

    // Feature Description
    ctx.fillStyle = colors.textMutedColor;
    ctx.font = `400 ${Math.round(18 * s)}px "Inter", sans-serif`;
    wrapText(ctx, feat.desc, fX + 90 * s, fY + 34 * s, featureColWidth - 40 * s, 26 * s);
  });
  ctx.restore();

  // Export as selected image format
  const mimeType = config.format === "jpeg" ? "image/jpeg" : config.format === "webp" ? "image/webp" : "image/png";
  return canvas.toDataURL(mimeType, 0.95);
}
