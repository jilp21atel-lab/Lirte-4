import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import appLogo from "../assets/images/app_logo.jpg";

interface SplashProps {
  onComplete: () => void;
}

const STAGES = [
  { progress: 15, text: "Initializing AI models..." },
  { progress: 35, text: "Loading perspective mockups..." },
  { progress: 60, text: "Preparing Design System workspace..." },
  { progress: 85, text: "Calibrating vector canvases..." },
  { progress: 100, text: "Ready ✓" }
];

export function Splash({ onComplete }: SplashProps) {
  const [currentStage, setCurrentStage] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Stagger loading indicators smoothly
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        
        const nextProgress = prev + Math.floor(Math.random() * 8) + 3;
        const bounded = Math.min(nextProgress, 100);
        
        // Match current text stage
        const matchingStage = STAGES.findIndex(s => bounded <= s.progress);
        if (matchingStage !== -1) {
          setCurrentStage(matchingStage);
        }
        
        return bounded;
      });
    }, 150);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      const timeout = setTimeout(() => {
        onComplete();
      }, 800);
      return () => clearTimeout(timeout);
    }
  }, [progress, onComplete]);

  return (
    <motion.div 
      id="splash-screen"
      className="fixed inset-0 bg-brand-forest text-white flex flex-col items-center justify-center z-50 p-6 select-none"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, transition: { duration: 0.6, ease: "easeInOut" } }}
    >
      {/* Brand Logo and Title */}
      <div className="flex flex-col items-center max-w-sm w-full text-center">
        <motion.div
          className="w-20 h-20 rounded-2xl bg-white overflow-hidden border border-brand-lime/30 flex items-center justify-center shadow-lg mb-6 p-1.5"
          initial={{ scale: 0.8, rotate: -20 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 100, damping: 10 }}
        >
          <img
            src={appLogo}
            alt="Mascot Logo"
            className="w-full h-full object-contain rounded-xl"
            id="splash-sparkle"
            referrerPolicy="no-referrer"
          />
        </motion.div>
        
        <motion.h1 
          className="text-4xl font-black font-display tracking-tight text-white mb-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          APP/4
        </motion.h1>
        
        <motion.p 
          className="text-brand-lime/80 text-xs font-mono tracking-widest uppercase mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.8 }}
          transition={{ delay: 0.3 }}
        >
          AI POSTER GENERATOR ENGINE
        </motion.p>

        {/* Custom Progress Bar Bar */}
        <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden relative mb-4 shadow-inner">
          <motion.div 
            className="h-full bg-brand-lime rounded-full shadow-[0_0_8px_rgba(159,232,112,0.6)]"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: "easeOut" }}
          />
        </div>

        {/* Responsive Stage Indicator */}
        <div className="h-6 flex items-center justify-center w-full">
          <AnimatePresence mode="wait">
            <motion.span
              key={currentStage}
              className="text-[11px] font-mono tracking-wider text-white/75 uppercase"
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
            >
              {STAGES[currentStage]?.text || "Initializing..."}
            </motion.span>
          </AnimatePresence>
        </div>

        {/* Numerical indicator */}
        <motion.span 
          className="text-xs font-bold font-mono text-brand-lime mt-1"
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          {progress}%
        </motion.span>
      </div>
    </motion.div>
  );
}
