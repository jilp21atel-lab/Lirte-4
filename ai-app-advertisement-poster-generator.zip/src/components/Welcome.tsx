import { motion } from "motion/react";
import { ArrowRight, ShieldCheck, Heart, Zap, Globe } from "lucide-react";
import appLogo from "../assets/images/app_logo.jpg";

interface WelcomeProps {
  onContinue: (asGuest: boolean) => void;
}

export function Welcome({ onContinue }: WelcomeProps) {
  return (
    <div id="welcome-screen" className="min-h-screen bg-brand-paper flex flex-col justify-between p-6 select-none relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] rounded-full bg-brand-lime/10 blur-3xl pointer-events-none" />
      <div className="absolute bottom-[-25%] right-[-20%] w-[90%] h-[90%] rounded-full bg-brand-fog blur-3xl pointer-events-none" />

      {/* Header bar */}
      <header className="max-w-7xl mx-auto w-full flex justify-between items-center py-4 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-white overflow-hidden border border-brand-border/10 flex items-center justify-center shadow-sm p-0.5 animate-pulse">
            <img src={appLogo} alt="Mascot Logo" className="w-full h-full object-contain rounded-lg" id="welcome-header-sparkle" referrerPolicy="no-referrer" />
          </div>
          <span className="text-xl font-black font-display tracking-tight text-brand-heading">APP/4</span>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-brand-charcoal bg-brand-fog px-3 py-1.5 rounded-full border border-brand-border/10">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-lime animate-ping" />
          SYSTEM LIVE
        </div>
      </header>

      {/* Main hero showcase block */}
      <main className="max-w-4xl mx-auto w-full flex flex-col items-center text-center my-auto py-12 relative z-10">
        <motion.div
          className="inline-flex items-center gap-2 bg-brand-forest text-brand-lime pl-2 pr-3.5 py-1 rounded-full text-xs font-semibold tracking-wider uppercase mb-8 shadow-md cursor-default"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
        >
          <div className="w-5 h-5 rounded-full bg-white overflow-hidden p-0.5 flex items-center justify-center animate-bounce">
            <img src={appLogo} alt="Mascot Logo" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
          </div>
          AI Poster Composition Engine v1.0
        </motion.div>

        <motion.h2 
          className="text-4xl md:text-7xl font-black font-display tracking-tighter leading-[0.95] text-brand-heading uppercase max-w-3xl mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          CREATE STUNNING <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-forest to-brand-dark-green underline decoration-brand-lime decoration-wavy decoration-2">
            APP ADVERTISEMENTS
          </span> <br />
          WITH ADVANCED AI
        </motion.h2>

        <motion.p 
          className="text-brand-charcoal text-base md:text-lg max-w-xl mb-12 leading-relaxed"
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.8 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          Type your app concept or details, and instantly generate three tailored, gorgeous ad variations. Customize phone mockups, angles, colors, and download in crystal-clear 4K.
        </motion.p>

        {/* Big Rounded Buttons */}
        <motion.div 
          className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto items-center justify-center mb-16"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <button
            onClick={() => onContinue(true)}
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-brand-lime text-brand-forest font-bold font-display text-base tracking-tight hover:scale-[1.03] active:scale-[0.98] hover:shadow-lg transition-all duration-300 flex items-center justify-center gap-2.5 group cursor-pointer"
          >
            Get Started As Guest
            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
          
          <button
            onClick={() => onContinue(false)}
            className="w-full sm:w-auto px-8 py-4 rounded-full bg-white text-brand-forest border border-brand-forest/20 font-bold font-display text-base tracking-tight hover:bg-brand-fog hover:border-brand-forest active:scale-[0.98] transition-all duration-300 cursor-pointer"
          >
            Sign In with Account
          </button>
        </motion.div>

        {/* Feature Highlights Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 w-full text-left border-t border-brand-border/10 pt-12">
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-brand-lime/20 flex items-center justify-center text-brand-forest">
              <Zap size={16} />
            </div>
            <h4 className="font-bold text-sm text-brand-heading">Instant Renditions</h4>
            <p className="text-xs text-brand-charcoal/80">3 fully layered variations rendered in under 5 seconds.</p>
          </div>
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-brand-lime/20 flex items-center justify-center text-brand-forest">
              <Globe size={16} />
            </div>
            <h4 className="font-bold text-sm text-brand-heading">3D Perspectives</h4>
            <p className="text-xs text-brand-charcoal/80">Swap phone angles, shadows, and reflections on-the-fly.</p>
          </div>
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-brand-lime/20 flex items-center justify-center text-brand-forest">
              <ShieldCheck size={16} />
            </div>
            <h4 className="font-bold text-sm text-brand-heading">4K Ultra Exports</h4>
            <p className="text-xs text-brand-charcoal/80">Download posters optimized for app stores & socials.</p>
          </div>
          <div className="space-y-1.5">
            <div className="w-8 h-8 rounded-lg bg-brand-lime/20 flex items-center justify-center text-brand-forest">
              <Heart size={16} />
            </div>
            <h4 className="font-bold text-sm text-brand-heading">Tailwind Inspired</h4>
            <p className="text-xs text-brand-charcoal/80">Highly editable component structures in pixel perfection.</p>
          </div>
        </div>
      </main>

      {/* Footer bar */}
      <footer className="max-w-7xl mx-auto w-full text-center py-6 border-t border-brand-border/10 text-xs text-brand-charcoal/60 relative z-10">
        © 2026 APP/4 – Powered by Google Gemini AI. Crafted with extreme premium care.
      </footer>
    </div>
  );
}
