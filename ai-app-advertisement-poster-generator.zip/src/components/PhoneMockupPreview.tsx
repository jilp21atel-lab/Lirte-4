import React from "react";
import { PosterColors } from "../types";
import { motion } from "motion/react";

interface PhoneMockupPreviewProps {
  deviceAngle: "front" | "left" | "right" | "floating" | "landscape" | "showcase";
  deviceFrame: "black" | "white" | "titanium";
  shadowOn: boolean;
  reflectionOn: boolean;
  zoom: number; // 0.5 to 1.5
  rotate: number; // -180 to 180 degrees
  posterColors: PosterColors;
  children: React.ReactNode; // Renders the <PosterRenderer /> inside
}

export function PhoneMockupPreview({
  deviceAngle,
  deviceFrame,
  shadowOn,
  reflectionOn,
  zoom = 1.0,
  rotate = 0,
  posterColors,
  children
}: PhoneMockupPreviewProps) {
  
  // Decide phone bezel styling based on frame selection
  const getBezelStyles = () => {
    switch (deviceFrame) {
      case "white":
        return {
          bezel: "bg-gray-100 border-gray-300 shadow-[inset_0_0_4px_rgba(255,255,255,0.8),_0_2px_4px_rgba(0,0,0,0.1)]",
          rim: "border-gray-200"
        };
      case "titanium":
        return {
          bezel: "bg-linear-to-b from-[#8E8A83] via-[#AEA59B] to-[#736E67] border-[#AEA59B]/50 shadow-[inset_0_1px_2px_rgba(255,255,255,0.4),_0_2px_8px_rgba(0,0,0,0.15)]",
          rim: "border-[#6C6760]"
        };
      case "black":
      default:
        return {
          bezel: "bg-linear-to-b from-[#1E2022] via-[#2F3235] to-[#121314] border-[#2D3135] shadow-[inset_0_1px_1px_rgba(255,255,255,0.15),_0_2px_10px_rgba(0,0,0,0.3)]",
          rim: "border-black"
        };
    }
  };

  const { bezel, rim } = getBezelStyles();

  // Combine angle/perspective transforms
  const getTransformStyles = () => {
    const baseScale = zoom;
    
    switch (deviceAngle) {
      case "left":
        return {
          transform: `perspective(1000px) rotateY(-18deg) rotateX(10deg) rotateZ(${rotate}deg) scale(${baseScale * 0.95})`,
          transition: "transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)"
        };
      case "right":
        return {
          transform: `perspective(1000px) rotateY(18deg) rotateX(10deg) rotateZ(${rotate}deg) scale(${baseScale * 0.95})`,
          transition: "transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)"
        };
      case "landscape":
        return {
          transform: `perspective(1000px) rotateZ(${90 + rotate}deg) scale(${baseScale * 0.82})`,
          transition: "transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)"
        };
      case "showcase":
        return {
          transform: `perspective(1000px) rotateX(12deg) rotateY(-8deg) rotateZ(${-2 + rotate}deg) scale(${baseScale * 0.95})`,
          transition: "transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)"
        };
      case "floating":
        // Handled by framer-motion float animation
        return {
          transform: `rotateZ(${rotate}deg) scale(${baseScale})`,
          transition: "transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)"
        };
      case "front":
      default:
        return {
          transform: `rotateZ(${rotate}deg) scale(${baseScale})`,
          transition: "transform 0.5s cubic-bezier(0.2, 0.8, 0.2, 1)"
        };
    }
  };

  // Shadow classes
  const shadowClass = shadowOn 
    ? "shadow-[0_25px_60px_-15px_rgba(0,0,0,0.4)]" 
    : "shadow-none";

  // Dynamic Ambient Bleed Glow for Studio Showcase mode
  const renderShowcaseGlow = () => {
    if (deviceAngle !== "showcase") return null;
    return (
      <div 
        className="absolute -inset-10 rounded-[50px] blur-3xl opacity-35 -z-10 transition-all duration-700 scale-110 pointer-events-none"
        style={{
          background: `radial-gradient(circle, ${posterColors.accentColor} 0%, transparent 70%)`
        }}
      />
    );
  };

  return (
    <div className="relative flex items-center justify-center py-12 px-6 overflow-visible w-full select-none">
      
      {/* 3D Showcase Glow */}
      {renderShowcaseGlow()}

      <motion.div
        id="phone-mockup-wrapper"
        style={getTransformStyles()}
        className={`relative transition-all duration-500`}
        animate={deviceAngle === "floating" ? {
          y: [0, -10, 0],
        } : { y: 0 }}
        transition={deviceAngle === "floating" ? {
          repeat: Infinity,
          duration: 3.5,
          ease: "easeInOut"
        } : undefined}
      >
        
        {/* Outer Bezel Ring (Simulated Hardware Frame) */}
        <div 
          className={`p-[14px] rounded-[42px] ${bezel} ${shadowClass} relative transition-all duration-300`}
        >
          {/* Inner Black Bezel Rim */}
          <div className={`rounded-[30px] border-[3px] ${rim} bg-black overflow-hidden relative p-1`}>
            
            {/* Glossy Sheen Overlay */}
            {reflectionOn && (
              <div 
                className="absolute inset-0 bg-linear-to-tr from-white/0 via-white/10 to-white/0 pointer-events-none z-30 mix-blend-overlay rotate-[35deg] scale-150 origin-center translate-y-[-10%]"
              />
            )}

            {/* Content Stage (Renders Poster Renderer component) */}
            <div className="relative rounded-[24px] overflow-hidden bg-black">
              {children}
            </div>

            {/* Screen Mask Rounded Notch overlay inside frame */}
            <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-full z-40 flex items-center justify-center">
              {/* Camera dot reflection */}
              <div className="w-2.5 h-2.5 rounded-full bg-blue-950 border border-blue-900/40 ml-auto mr-3 flex items-center justify-center opacity-70">
                <div className="w-1 h-1 rounded-full bg-cyan-400 opacity-50" />
              </div>
            </div>

          </div>

          {/* Physical Side Buttons Overlay */}
          <div className="absolute left-[-2px] top-32 w-[3px] h-10 bg-current opacity-60 rounded-r-xs" />
          <div className="absolute left-[-2px] top-48 w-[3px] h-16 bg-current opacity-60 rounded-r-xs" />
          <div className="absolute left-[-2px] top-68 w-[3px] h-16 bg-current opacity-60 rounded-r-xs" />
          <div className="absolute right-[-2px] top-44 w-[3px] h-20 bg-current opacity-60 rounded-l-xs" />

        </div>
      </motion.div>
    </div>
  );
}
