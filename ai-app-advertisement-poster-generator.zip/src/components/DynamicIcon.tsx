import { 
  Shield, 
  Zap, 
  Wallet, 
  TrendingUp, 
  Star, 
  Target, 
  Compass, 
  Flame, 
  Activity, 
  Check, 
  Cloud, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Bell, 
  Settings, 
  Cpu,
  Smartphone,
  Sparkles,
  Download,
  Share2,
  Trash2,
  Bookmark,
  ChevronRight,
  Plus,
  Send,
  User,
  LogOut,
  Sliders,
  Maximize2,
  RotateCw,
  ZoomIn,
  Search,
  MessageSquare,
  Sparkle,
  Image,
  RefreshCw,
  Heart,
  Grid
} from "lucide-react";

interface DynamicIconProps {
  name: string;
  className?: string;
  size?: number;
}

export function DynamicIcon({ name, className = "", size = 20 }: DynamicIconProps) {
  const normalized = name.toLowerCase().replace(/[-_]/g, "");

  switch (normalized) {
    case "shield":
      return <Shield className={className} size={size} id={`icon-shield-${name}`} />;
    case "zap":
      return <Zap className={className} size={size} id={`icon-zap-${name}`} />;
    case "wallet":
      return <Wallet className={className} size={size} id={`icon-wallet-${name}`} />;
    case "trendingup":
    case "trending":
      return <TrendingUp className={className} size={size} id={`icon-trendingup-${name}`} />;
    case "star":
      return <Star className={className} size={size} id={`icon-star-${name}`} />;
    case "target":
      return <Target className={className} size={size} id={`icon-target-${name}`} />;
    case "compass":
      return <Compass className={className} size={size} id={`icon-compass-${name}`} />;
    case "flame":
      return <Flame className={className} size={size} id={`icon-flame-${name}`} />;
    case "activity":
      return <Activity className={className} size={size} id={`icon-activity-${name}`} />;
    case "check":
      return <Check className={className} size={size} id={`icon-check-${name}`} />;
    case "cloud":
      return <Cloud className={className} size={size} id={`icon-cloud-${name}`} />;
    case "arrowupright":
      return <ArrowUpRight className={className} size={size} id={`icon-arrowupright-${name}`} />;
    case "arrowdownleft":
      return <ArrowDownLeft className={className} size={size} id={`icon-arrowdownleft-${name}`} />;
    case "bell":
      return <Bell className={className} size={size} id={`icon-bell-${name}`} />;
    case "settings":
      return <Settings className={className} size={size} id={`icon-settings-${name}`} />;
    case "cpu":
      return <Cpu className={className} size={size} id={`icon-cpu-${name}`} />;
    case "smartphone":
      return <Smartphone className={className} size={size} id={`icon-smartphone-${name}`} />;
    case "sparkles":
      return <Sparkles className={className} size={size} id={`icon-sparkles-${name}`} />;
    case "download":
      return <Download className={className} size={size} id={`icon-download-${name}`} />;
    case "share":
    case "share2":
      return <Share2 className={className} size={size} id={`icon-share-${name}`} />;
    case "trash":
    case "trash2":
      return <Trash2 className={className} size={size} id={`icon-trash-${name}`} />;
    case "bookmark":
      return <Bookmark className={className} size={size} id={`icon-bookmark-${name}`} />;
    case "chevronright":
      return <ChevronRight className={className} size={size} id={`icon-chevronright-${name}`} />;
    case "plus":
      return <Plus className={className} size={size} id={`icon-plus-${name}`} />;
    case "send":
      return <Send className={className} size={size} id={`icon-send-${name}`} />;
    case "user":
      return <User className={className} size={size} id={`icon-user-${name}`} />;
    case "logout":
      return <LogOut className={className} size={size} id={`icon-logout-${name}`} />;
    case "sliders":
      return <Sliders className={className} size={size} id={`icon-sliders-${name}`} />;
    case "maximize":
    case "maximize2":
      return <Maximize2 className={className} size={size} id={`icon-maximize-${name}`} />;
    case "rotate":
    case "rotatecw":
      return <RotateCw className={className} size={size} id={`icon-rotate-${name}`} />;
    case "zoom":
    case "zoomin":
      return <ZoomIn className={className} size={size} id={`icon-zoom-${name}`} />;
    case "search":
      return <Search className={className} size={size} id={`icon-search-${name}`} />;
    case "messagesquare":
      return <MessageSquare className={className} size={size} id={`icon-messagesquare-${name}`} />;
    case "sparkle":
      return <Sparkle className={className} size={size} id={`icon-sparkle-${name}`} />;
    case "image":
      return <Image className={className} size={size} id={`icon-image-${name}`} />;
    case "refresh":
    case "refreshcw":
      return <RefreshCw className={className} size={size} id={`icon-refresh-${name}`} />;
    case "heart":
      return <Heart className={className} size={size} id={`icon-heart-${name}`} />;
    case "grid":
      return <Grid className={className} size={size} id={`icon-grid-${name}`} />;
    default:
      return <Sparkles className={className} size={size} id={`icon-fallback-${name}`} />;
  }
}
