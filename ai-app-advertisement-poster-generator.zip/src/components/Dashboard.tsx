import React, { useState } from "react";
import { Project } from "../types";
import { Plus, Sparkles, Folder, Calendar, ArrowRight, Grid, Heart } from "lucide-react";

interface DashboardProps {
  projects: Project[];
  onSelectProject: (project: Project) => void;
  onNewProject: (name: string, category: string, themeStyle: string) => void;
}

const TEMPLATE_PRESETS = [
  { name: "Fintech Premium", category: "Finance", theme: "Glassmorphic Dark", description: "Vibrant orange/yellow neon accents with minimalist metrics." },
  { name: "FitPulse Workout", category: "Health & Fitness", theme: "Vibrant Gradient", description: "Bold lime green indicators with high-contrast active curves." },
  { name: "TaskSync AI", category: "Productivity", theme: "Minimalist Editorial", description: "Elegant whitespace with sharp displays and checklist timelines." },
  { name: "CryptoFlow Wallet", category: "Crypto", theme: "Cyberpunk Dark", description: "Glowing violet and pink grids with detailed balance tracking." }
];

export function Dashboard({ projects, onSelectProject, onNewProject }: DashboardProps) {
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Finance");
  const [themeStyle, setThemeStyle] = useState("Minimalist Editorial");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onNewProject(name, category, themeStyle);
    setName("");
    setShowModal(false);
  };

  const handleApplyTemplate = (tpl: typeof TEMPLATE_PRESETS[0]) => {
    onNewProject(`${tpl.name} Promo`, tpl.category, tpl.theme);
  };

  return (
    <div id="dashboard-view" className="min-h-screen bg-brand-fog/40 p-6 md:p-10 select-none">
      <div className="max-w-6xl mx-auto space-y-12">
        
        {/* Header Block with Wise style title */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-brand-border/10 pb-8">
          <div>
            <span className="text-xs font-mono tracking-widest text-brand-forest/60 uppercase font-semibold">WORKSPACE DIRECTORY</span>
            <h1 className="text-3xl md:text-5xl font-black font-display tracking-tight text-brand-heading mt-1 uppercase">
              MY POSTER DESIGNS
            </h1>
          </div>
          
          <button
            onClick={() => setShowModal(true)}
            className="self-start px-6 py-3.5 rounded-full bg-brand-lime text-brand-forest font-bold font-display text-sm tracking-tight hover:scale-[1.03] active:scale-[0.98] hover:shadow-md transition-all duration-300 flex items-center gap-2 cursor-pointer"
          >
            <Plus size={16} />
            Create New Project
          </button>
        </div>

        {/* Dashboard Grid split: New project callout + Projects list */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main callout block */}
          <div className="bg-brand-forest text-white p-8 rounded-[28px] shadow-xl flex flex-col justify-between relative overflow-hidden group min-h-[320px]">
            {/* Background glowing circle */}
            <div className="absolute top-[-10%] right-[-15%] w-48 h-48 rounded-full bg-brand-lime/10 blur-2xl group-hover:scale-125 transition-transform duration-700" />
            
            <div className="space-y-4 relative z-10">
              <div className="w-10 h-10 rounded-full bg-brand-lime flex items-center justify-center text-brand-forest shadow-md">
                <Sparkles size={18} />
              </div>
              <h3 className="text-2xl font-bold font-display uppercase tracking-tight leading-tight">
                AI CO-PILOT <br />IS READY.
              </h3>
              <p className="text-xs text-brand-fog/80 leading-relaxed">
                Describe your application, choose a layout, and let Gemini craft high-impact ad banners complete with device frames and features.
              </p>
            </div>

            <button
              onClick={() => setShowModal(true)}
              className="mt-8 px-5 py-3 rounded-full bg-white text-brand-forest text-xs font-bold tracking-wider uppercase hover:bg-brand-lime hover:text-brand-forest transition-colors duration-300 flex items-center justify-center gap-2 group cursor-pointer"
            >
              Get Creative Now
              <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>

          {/* Existing Projects Panel */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-mono font-bold tracking-widest text-brand-charcoal uppercase">
                RECENT PROJECTS ({projects.length})
              </h4>
            </div>

            {projects.length === 0 ? (
              <div className="border border-dashed border-brand-border/30 rounded-[28px] p-12 text-center flex flex-col items-center justify-center bg-white shadow-sm min-h-[250px]">
                <div className="w-12 h-12 rounded-full bg-brand-fog flex items-center justify-center text-brand-charcoal/60 mb-4">
                  <Folder size={20} />
                </div>
                <h5 className="font-bold text-base text-brand-heading">No Projects Found</h5>
                <p className="text-xs text-brand-charcoal/70 mt-1 max-w-xs">
                  Get started by creating your very first AI poster ad. It takes less than 30 seconds.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projects.map((proj) => {
                  const dateString = new Date(proj.createdAt).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                  });
                  const activePoster = proj.posters[proj.selectedPosterIndex] || proj.posters[0];
                  
                  return (
                    <div
                      key={proj.id}
                      onClick={() => onSelectProject(proj)}
                      className="group bg-white p-5 rounded-[20px] border border-brand-border/10 hover:border-brand-forest/20 shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between cursor-pointer"
                    >
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <span className="text-[10px] font-bold font-mono tracking-wider px-2 py-1 bg-brand-fog rounded-full text-brand-forest uppercase">
                            {proj.category}
                          </span>
                          <span className="text-[10px] font-mono text-brand-charcoal/50 flex items-center gap-1">
                            <Calendar size={11} />
                            {dateString}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-bold text-lg text-brand-heading group-hover:text-brand-forest transition-colors uppercase font-display leading-tight">
                            {proj.name}
                          </h4>
                          <p className="text-xs text-brand-charcoal/70 line-clamp-2 mt-1 leading-relaxed">
                            {proj.prompt || "No custom prompt description provided."}
                          </p>
                        </div>
                      </div>

                      <div className="mt-6 pt-4 border-t border-brand-border/5 flex items-center justify-between">
                        <span className="text-[10px] font-mono text-brand-charcoal/60">
                          {proj.posters.length} Poster Drafts
                        </span>
                        <div className="w-6 h-6 rounded-full bg-brand-fog text-brand-forest flex items-center justify-center group-hover:bg-brand-lime group-hover:scale-115 transition-all">
                          <Plus size={11} />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Templates Presets Section */}
        <div className="space-y-5">
          <div className="flex items-center gap-2">
            <Grid size={15} className="text-brand-forest" />
            <h4 className="text-xs font-mono font-bold tracking-widest text-brand-charcoal uppercase">
              QUICK START TEMPLATES
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {TEMPLATE_PRESETS.map((tpl, idx) => (
              <div 
                key={idx}
                onClick={() => handleApplyTemplate(tpl)}
                className="bg-white p-5 rounded-[20px] border border-brand-border/10 hover:border-brand-forest shadow-xs hover:shadow-lg transition-all duration-300 text-left flex flex-col justify-between cursor-pointer group"
              >
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-mono font-bold text-brand-forest bg-brand-lime/20 px-2 py-0.5 rounded-full">
                      {tpl.category}
                    </span>
                    <Heart size={12} className="text-brand-charcoal/30 hover:text-brand-error" />
                  </div>
                  <h5 className="font-bold text-sm text-brand-heading uppercase font-display tracking-tight group-hover:text-brand-forest transition-colors">
                    {tpl.name}
                  </h5>
                  <p className="text-[11px] text-brand-charcoal/80 leading-normal line-clamp-3">
                    {tpl.description}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-brand-border/5 text-[10px] font-mono text-brand-charcoal/50 flex justify-between items-center">
                  <span>{tpl.theme}</span>
                  <span className="text-brand-forest group-hover:translate-x-0.5 transition-transform">→</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* New Project Dialog Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-brand-forest/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div 
            className="bg-white rounded-[28px] max-w-md w-full p-6 md:p-8 shadow-2xl relative overflow-hidden animate-scale-in border border-brand-border/10"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Glow */}
            <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-brand-lime/20 blur-xl pointer-events-none" />
            
            <h3 className="text-2xl font-bold font-display uppercase tracking-tight text-brand-heading mb-6 flex items-center gap-2">
              <Sparkles size={20} className="text-brand-forest" />
              Start New Project
            </h3>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Name */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-brand-charcoal uppercase block">App Name</label>
                <input 
                  type="text" 
                  value={name} 
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. WalletFlow, FitPulse"
                  required
                  className="w-full px-4 py-3 rounded-xl border border-brand-border/20 focus:border-brand-forest focus:outline-none bg-brand-fog/20 font-medium text-sm text-brand-heading"
                />
              </div>

              {/* Category */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-brand-charcoal uppercase block">Category</label>
                <select 
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-brand-border/20 focus:border-brand-forest focus:outline-none bg-brand-fog/20 font-medium text-sm text-brand-heading cursor-pointer"
                >
                  <option value="Finance">Finance / Fintech</option>
                  <option value="Health & Fitness">Health & Fitness</option>
                  <option value="Productivity">Productivity / SaaS</option>
                  <option value="Social Media">Social Media / Chat</option>
                  <option value="Crypto">Crypto / Web3</option>
                  <option value="Travel & Guide">Travel / Navigation</option>
                  <option value="Utilities">Utilities / Tools</option>
                </select>
              </div>

              {/* Theme Preference Style */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-brand-charcoal uppercase block">Design Theme Preference</label>
                <select 
                  value={themeStyle}
                  onChange={(e) => setThemeStyle(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-brand-border/20 focus:border-brand-forest focus:outline-none bg-brand-fog/20 font-medium text-sm text-brand-heading cursor-pointer"
                >
                  <option value="Minimalist Editorial">Minimalist Editorial (Wise Inspired)</option>
                  <option value="Glassmorphic Dark">Glassmorphism (Translucent Cards)</option>
                  <option value="Vibrant Gradient">Vibrant High-Contrast Gradient</option>
                  <option value="Cyberpunk Dark">Cyberpunk / Dark Neon Grid</option>
                  <option value="Neo-Brutalist">Neo-Brutalist / Bold Shapes</option>
                </select>
              </div>

              {/* Action buttons */}
              <div className="flex gap-3 pt-4">
                <button 
                  type="button" 
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-3 rounded-full border border-brand-border/20 font-bold font-display text-xs tracking-wider uppercase text-brand-charcoal hover:bg-brand-fog transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-3 rounded-full bg-brand-lime text-brand-forest font-bold font-display text-xs tracking-wider uppercase hover:shadow-md transition-shadow cursor-pointer"
                >
                  Configure
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
