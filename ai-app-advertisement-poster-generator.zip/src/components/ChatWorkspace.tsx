import React, { useState, useEffect, useRef } from "react";
import { Project, PosterVariation, ChatMessage } from "../types";
import { DynamicIcon } from "./DynamicIcon";
import { PosterRenderer } from "./PosterRenderer";
import { PhoneMockupPreview } from "./PhoneMockupPreview";
import { exportPosterToImage, ExportConfig } from "../utils/canvasExporter";
import { 
  Sparkles, 
  Send, 
  ArrowLeft, 
  Bookmark, 
  ChevronRight, 
  Download, 
  Maximize2, 
  Settings, 
  RefreshCw, 
  Heart, 
  Info,
  Check,
  Edit3,
  Sliders,
  Compass,
  FileImage,
  Mic,
  Image as ImageIcon
} from "lucide-react";

interface ChatWorkspaceProps {
  project: Project;
  onBack: () => void;
  onUpdateProject: (updated: Project) => void;
}

const PROMPT_SUGGESTIONS = [
  "Premium forest green and lime theme with active efficiency lines",
  "Minimalist paper-white theme with massive bold typography and dark items",
  "Futuristic cyberpunk layout with violet background and glowing pink metrics",
  "Vibrant orange-to-black neon gradient with circular bento dividers"
];

export function ChatWorkspace({ project, onBack, onUpdateProject }: ChatWorkspaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputPrompt, setInputPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Loader Timeline states
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generationStageText, setGenerationStageText] = useState("");

  // Selected Poster State
  const [selectedPosterIndex, setSelectedPosterIndex] = useState(0);
  const currentPoster = project.posters[selectedPosterIndex] || project.posters[0];

  // AI Modal and Custom Vector engine configurations
  const [aiEngine, setAiEngine] = useState<"gemini" | "openai">("gemini");
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [vectorPrompt, setVectorPrompt] = useState("");
  const [isGeneratingVector, setIsGeneratingVector] = useState(false);
  const [vectorGenerationMessage, setVectorGenerationMessage] = useState("");
  const [nenoMood, setNenoMood] = useState<"creative" | "hyperactive" | "cyberpunk" | "retro">("creative");

  // Live Phone Mockup parameters
  const [deviceAngle, setDeviceAngle] = useState<"front" | "left" | "right" | "floating" | "landscape" | "showcase">("front");
  const [deviceFrame, setDeviceFrame] = useState<"black" | "white" | "titanium">("black");
  const [shadowOn, setShadowOn] = useState(true);
  const [reflectionOn, setReflectionOn] = useState(true);
  const [zoom, setZoom] = useState(1.0);
  const [rotate, setRotate] = useState(0);
  const [isEditable, setIsEditable] = useState(false);

  // Download engine parameters
  const [downloadFormat, setDownloadFormat] = useState<"png" | "jpeg" | "webp">("png");
  const [downloadQuality, setDownloadQuality] = useState<"standard" | "hd" | "4k">("hd");
  const [downloadRatio, setDownloadRatio] = useState<"story" | "square" | "ultra" | "appstore" | "banner">("story");
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadCompletedMessage, setDownloadCompletedMessage] = useState("");

  // Favorites / Bookmarked posters registry
  const [favorites, setFavorites] = useState<number[]>([]);

  // Workspace Switch Mode State
  const [workspaceMode, setWorkspaceMode] = useState<"poster" | "image-bot">("image-bot");

  // Multi-Image ChatBot Mode States
  interface ImageBotMessage {
    id: string;
    sender: "user" | "ai";
    text: string;
    timestamp: string;
    images?: string[]; // 3 images generated at once
  }
  const [botMessages, setBotMessages] = useState<ImageBotMessage[]>([]);
  const [botInputPrompt, setBotInputPrompt] = useState("");
  const [isBotGenerating, setIsBotGenerating] = useState(false);
  const [botGenerationProgress, setBotGenerationProgress] = useState(0);
  const [botStageText, setBotStageText] = useState("");
  
  // Custom Background Skin applied on mobile mockup
  const [selectedSkinImage, setSelectedSkinImage] = useState<string | null>(null);
  const [showAppOverlay, setShowAppOverlay] = useState(true);

  // 4x Quality Upscaler / Improvement states
  const [upscalingImageUrl, setUpscalingImageUrl] = useState<string | null>(null);
  const [upscaleProgress, setUpscaleProgress] = useState(0);
  const [upscaledImages, setUpscaledImages] = useState<string[]>([]);

  const handleUpscaleImage = (imgUrl: string) => {
    if (upscalingImageUrl) return;
    setUpscalingImageUrl(imgUrl);
    setUpscaleProgress(0);
    const interval = setInterval(() => {
      setUpscaleProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setUpscalingImageUrl(null);
            setUpscaledImages((prevList) => {
              if (prevList.includes(imgUrl)) return prevList;
              return [...prevList, imgUrl];
            });
          }, 600);
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  // Ref for chat auto-scrolling
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Initialize Chat History with Co-pilot greeting
  useEffect(() => {
    const greetingMsg: ChatMessage = {
      id: "greeting-0",
      sender: "ai",
      text: `Hello! I am your APP/4 design co-pilot. I am ready to craft stunning ad posters for your app **${project.name}** under the **${project.category}** category.\n\nDescribe the visual style, colors, and layout you want (e.g., *"dark mode, premium orange gradients, active analytics line"*), or select one of the suggested design prompt templates below to begin!`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };
    
    // If project already contains generated posters, show them in first greeting
    if (project.posters && project.posters.length > 0) {
      greetingMsg.text = `Welcome back to **${project.name}** workspace! Below are your generated poster drafts. Select any variation to load it inside the live 3D perspective phone mockup, customize details, or download in high-res.`;
      greetingMsg.posters = project.posters;
    }

    setMessages([greetingMsg]);
    setSelectedPosterIndex(project.selectedPosterIndex || 0);
  }, [project.id]);

  // Initialize Image Bot Greeting
  useEffect(() => {
    setBotMessages([
      {
        id: "bot-greeting-0",
        sender: "ai",
        text: `Welcome to the **Premium AI Multi-Image ChatBot Hub**! 🖼️📱\n\nI am configured with **Neno AI multi-image parallel generation**. Every prompt you send will automatically dispatch **3 beautiful, distinct design variants simultaneously**! 🚀\n\n### 🍎 MASTERING THE ART OF IMAGE PROMPTS\nTo generate ultra-realistic, luxury presentations resembling professional portfolio work on Dribbble & Behance, structure your prompts using these parameters:\n\n*   **Composition:** Floating mockup, dynamic perspective, large negative space, clean studio composition\n*   **Camera Style:** 35mm product photography, macro details, soft depth of field (DoF), cinematic framing\n*   **Lighting:** Soft studio lighting, diffused shadows, global illumination, premium glass reflections\n*   **Color Palette:** Orange, Black, and White (Swiss Graphic Design layout)\n*   **Rendering engine:** Octane / Redshift Render 8K HDR quality for maximum sharpness\n\n### 📱 INTERACTIVE PREVIEWS\nClick the **"📱 View on Mobile Skin"** button on any generated image to instantly wrap it inside the gorgeous, interactive 3D smartphone preview on the right! You can also click **"✨ image or 4 Times improve"** to upscale the design details on the fly.`,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      }
    ]);
  }, [project.id]);

  // Sync selectedSkinImage with currentPoster on poster change
  useEffect(() => {
    if (currentPoster?.appUI?.generatedImage) {
      setSelectedSkinImage(currentPoster.appUI.generatedImage);
    }
  }, [project.id, currentPoster]);

  // Scroll chat to bottom when messages update
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isGenerating, generationStageText, botMessages, isBotGenerating, botStageText]);

  // Handle poster select
  const handleSelectPoster = (index: number) => {
    setSelectedPosterIndex(index);
    const updated = {
      ...project,
      selectedPosterIndex: index
    };
    onUpdateProject(updated);
  };

  // Handle Multi-Image ChatBot prompt submissions
  const handleBotSubmit = async (promptText: string) => {
    if (!promptText.trim() || isBotGenerating) return;

    // Add user message
    const userMsgId = `user-bot-${Date.now()}`;
    const newMsg: ImageBotMessage = {
      id: userMsgId,
      sender: "user",
      text: promptText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };
    
    setBotMessages(prev => [...prev, newMsg]);
    setBotInputPrompt("");
    setIsBotGenerating(true);
    setBotGenerationProgress(10);
    setBotStageText("Dispatching 3 parallel generation workers...");

    // Create intervals for simulated loader
    const progressTimer = setInterval(() => {
      setBotGenerationProgress(p => {
        if (p >= 90) return 90;
        return p + 12;
      });
    }, 600);

    const stages = [
      "Connecting to Gemini API...",
      "Crafting multi-style variations...",
      "Cooking distinct canvas templates...",
      "Generating high-resolution backdrops...",
      "Finalizing vector layout grids..."
    ];

    let stageIdx = 0;
    const stageTimer = setInterval(() => {
      setBotStageText(stages[stageIdx % stages.length]);
      stageIdx++;
    }, 1000);

    try {
      const moodModifiers = {
        creative: ", styled with soft premium pastel artistic colors, elegant minimal compositions, high-end illustration style",
        hyperactive: ", styled with wild vibrant high-contrast colors, energetic abstract splatters, hyper-dynamic perspective, glitch-hop elements",
        cyberpunk: ", styled with glowing cyan, violet, magenta neon colors, futuristic cyber grids, wireframes, synthwave HUD graphics, highly immersive tech",
        retro: ", styled with 80s retro VHS aesthetic, warm sepia and vintage neon tones, textured scanlines, modular grid elements, vaporwave style"
      };

      const activeModifier = moodModifiers[nenoMood];

      // Make 3 parallel fetch requests to /api/generate-image with different styles to ensure variety
      const variationPrompts = [
        `${promptText}${activeModifier} (variation style A, sleek professional layout, clean vector composition)`,
        `${promptText}${activeModifier} (variation style B, creative isometric 3D model perspective, rich details)`,
        `${promptText}${activeModifier} (variation style C, high-fidelity premium textures, cinematic atmospheric light)`
      ];

      const fetchPromises = variationPrompts.map(async (vPrompt) => {
        try {
          const res = await fetch("/api/generate-image", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ prompt: vPrompt })
          });
          const data = await res.json();
          return data.imageUrl || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80";
        } catch (e) {
          console.error("Single generation error:", e);
          const fallbacks = [
            "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=600&q=80"
          ];
          return fallbacks[Math.floor(Math.random() * fallbacks.length)];
        }
      });

      const images = await Promise.all(fetchPromises);

      clearInterval(progressTimer);
      clearInterval(stageTimer);
      setBotGenerationProgress(100);
      setBotStageText("Complete ✓");

      // Add AI reply with the 3 images side-by-side
      const aiMsgId = `ai-bot-${Date.now()}`;
      setBotMessages(prev => [
        ...prev,
        {
          id: aiMsgId,
          sender: "ai",
          text: `Here are **3 unique visual variations** generated simultaneously for your description: \n*"${promptText}"*\n\nSelect **"📱 Apply to Mobile Screen"** on any image to overlay it live inside the 3D smartphone preview skin on the right!`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          images: images
        }
      ]);

      // Automatically apply the first image as current skin preview
      if (images[0]) {
        setSelectedSkinImage(images[0]);
      }
    } catch (err) {
      console.error("Bot generation failed:", err);
      clearInterval(progressTimer);
      clearInterval(stageTimer);
      
      setBotMessages(prev => [
        ...prev,
        {
          id: `ai-bot-err-${Date.now()}`,
          sender: "ai",
          text: `I ran into an issue connecting to the rendering node. I have selected 3 stunning high-resolution creative layouts for you to check out instead!`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          images: [
            "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&w=600&q=80",
            "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=600&q=80"
          ]
        }
      ]);
    } finally {
      setIsBotGenerating(false);
    }
  };

  // Toggle favorite bookmark state
  const handleToggleFavorite = (idx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites(prev => 
      prev.includes(idx) ? prev.filter(item => item !== idx) : [...prev, idx]
    );
  };

  // Live Inline Editing inside Mockup Screen
  const handlePosterDetailsChange = (updatedPoster: PosterVariation) => {
    const updatedPostersList = [...project.posters];
    updatedPostersList[selectedPosterIndex] = updatedPoster;
    onUpdateProject({
      ...project,
      posters: updatedPostersList
    });
  };

  // Simulated Loader timeline for Gemini generation
  const runGenerationProgressSimulator = async () => {
    setGenerationProgress(5);
    setGenerationStageText("Reading App characteristics...");
    await new Promise(r => setTimeout(r, 600));

    setGenerationProgress(20);
    setGenerationStageText("Enhancing prompt directives with design rules...");
    await new Promise(r => setTimeout(r, 900));

    setGenerationProgress(45);
    setGenerationStageText("AI Thinking & composing grid structures...");
    await new Promise(r => setTimeout(r, 1200));

    setGenerationProgress(70);
    setGenerationStageText("Rendering 3 visual poster variations...");
    await new Promise(r => setTimeout(r, 900));

    setGenerationProgress(90);
    setGenerationStageText("Finalizing vector curves & text alignment...");
    await new Promise(r => setTimeout(r, 600));

    setGenerationProgress(100);
    setGenerationStageText("Complete ✓");
  };

  // Call API to generate posters using Gemini
  const handleGenerate = async (promptText: string) => {
    if (!promptText.trim() || isGenerating) return;

    // Add user message
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: "user",
      text: promptText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };
    setMessages(prev => [...prev, userMsg]);
    setInputPrompt("");
    setIsGenerating(true);

    // Run custom loading screen progress
    const progressPromise = runGenerationProgressSimulator();

    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          appName: project.name,
          appCategory: project.category,
          prompt: promptText,
          themeStyle: project.themeStyle,
          aiEngine: aiEngine
        })
      });

      const data = await response.json();
      await progressPromise; // Make sure loading progress finishes nicely

      if (data && data.posters && data.posters.length > 0) {
        const generatedVariations: PosterVariation[] = data.posters;
        
        // Add AI message accompanied with 3 variations
        const aiMsg: ChatMessage = {
          id: `ai-${Date.now()}`,
          sender: "ai",
          text: `I have generated **3 distinct visual variations** styled for your app, utilizing custom typography weights, rounded pill components, and balanced margins:`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          posters: generatedVariations
        };

        setMessages(prev => [...prev, aiMsg]);
        
        // Save back to project state
        const updatedProject = {
          ...project,
          prompt: promptText,
          posters: generatedVariations,
          selectedPosterIndex: 0
        };
        onUpdateProject(updatedProject);
        setSelectedPosterIndex(0);
      } else {
        throw new Error("Invalid response format received from AI server.");
      }
    } catch (err: any) {
      console.error(err);
      const errMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: "ai",
        text: "I encountered a slight issue compiling visual variables. Please try again or simplify your style requirements.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };
      setMessages(prev => [...prev, errMsg]);
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
      setGenerationStageText("");
    }
  };

  // High-Res Canvas Download Exporter trigger
  const handleDownloadImage = async () => {
    if (!currentPoster) return;
    setIsDownloading(true);
    setDownloadCompletedMessage("");

    try {
      const config: ExportConfig = {
        format: downloadFormat,
        ratio: downloadRatio,
        quality: downloadQuality,
        deviceFrame: deviceFrame,
        shadowOn: shadowOn,
        reflectionOn: reflectionOn
      };

      // Get high-res data URL from canvas
      const dataUrl = await exportPosterToImage(currentPoster, config);

      // Trigger automatic browser download anchor
      const link = document.createElement("a");
      const cleanName = project.name.toLowerCase().replace(/\s+/g, "_");
      link.download = `${cleanName}_poster_${downloadRatio}_${downloadQuality}.${downloadFormat}`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setDownloadCompletedMessage("Asset exported successfully! Check downloads folder.");
      setTimeout(() => setDownloadCompletedMessage(""), 5000);
    } catch (err) {
      console.error("Export failed:", err);
      setDownloadCompletedMessage("Export failed. Please try with standard definition.");
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div id="workspace-layout" className="min-h-screen bg-white flex flex-col select-none">
      
      {/* Top Header Controls Bar */}
      <nav className="border-b border-brand-border/10 px-5 py-4 bg-white flex items-center justify-between z-20 flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={onBack}
            className="p-2 rounded-full hover:bg-brand-fog text-brand-forest transition-colors cursor-pointer"
            title="Back to Dashboard"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono tracking-widest text-brand-forest uppercase font-bold bg-brand-lime/25 px-2 py-0.5 rounded-full">
                {project.category}
              </span>
              <span className="text-[10px] font-mono text-brand-charcoal/50">
                Drafting Co-Pilot active
              </span>
            </div>
            <h2 className="text-base font-black font-display text-brand-heading uppercase tracking-tight">
              {project.name}
            </h2>
          </div>
        </div>

        {/* Workspace Mode Segmented Toggle Switch */}
        <div className="flex bg-brand-fog p-1 rounded-full border border-brand-border/10 shadow-xs">
          <button 
            onClick={() => setWorkspaceMode("poster")}
            className={`px-4.5 py-1.5 rounded-full text-[11px] font-black font-display uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-1.5 ${
              workspaceMode === "poster" 
                ? "bg-brand-forest text-brand-lime shadow-xs" 
                : "text-brand-charcoal hover:text-brand-heading"
            }`}
          >
            <span>📢 Poster Designer</span>
          </button>
          <button 
            onClick={() => setWorkspaceMode("image-bot")}
            className={`px-4.5 py-1.5 rounded-full text-[11px] font-black font-display uppercase tracking-wider transition-all duration-300 cursor-pointer flex items-center gap-1.5 ${
              workspaceMode === "image-bot" 
                ? "bg-brand-forest text-brand-lime shadow-xs" 
                : "text-brand-charcoal hover:text-brand-heading"
            }`}
          >
            <span>🖼️ Multi-Image Bot</span>
            <span className="bg-brand-lime/30 text-brand-forest text-[8px] font-mono font-black px-1 py-0.2 rounded">3x</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {/* AI Config modal trigger with playful spark personality */}
          <button
            onClick={() => setIsAIModalOpen(true)}
            className="px-4.5 py-2 rounded-full border border-brand-border/10 text-xs font-black font-display tracking-tight text-brand-forest hover:text-white bg-white hover:bg-brand-forest hover:scale-105 active:scale-95 shadow-xs hover:shadow-[0_0_15px_rgba(22,51,0,0.25)] transition-all duration-300 flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles size={13} className="text-brand-lime animate-pulse" />
            <span>🧠 BRAIN: {aiEngine === "gemini" ? "GEMINI PRO" : "GPT-4O-MINI"}</span>
          </button>

          {/* Direct Live Edit Toggle with tactile active design */}
          <button
            onClick={() => setIsEditable(!isEditable)}
            className={`px-4.5 py-2 rounded-full border text-xs font-black font-display tracking-tight transition-all duration-300 flex items-center gap-1.5 cursor-pointer transform active:scale-95 ${
              isEditable 
                ? "bg-brand-forest border-brand-forest text-brand-lime shadow-[0_0_15px_rgba(159,232,112,0.4)] animate-pulse" 
                : "bg-white border-brand-border/10 text-brand-charcoal hover:bg-brand-fog hover:scale-105"
            }`}
          >
            <Edit3 size={13} className={isEditable ? "animate-bounce" : ""} />
            {isEditable ? "✏️ LIVE CANVAS SCULPTING" : "✏️ INTERACTIVE EDIT"}
          </button>
        </div>
      </nav>

      {/* Main Grid: Responsive 3 Columns layout */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden h-[calc(100vh-73px)]">
        
        {/* PANEL 1: Quick Tools & Navigation (Left sidebar, col-span-2) */}
        <aside className="lg:col-span-2 border-r border-brand-border/10 bg-brand-fog/20 p-5 flex flex-col justify-between hidden lg:flex overflow-y-auto">
          {workspaceMode === "poster" ? (
            <div className="space-y-6">
              <div>
              <span className="text-[10px] font-mono tracking-wider font-semibold opacity-60 uppercase block">PROJECT OVERVIEW</span>
              <p className="text-xs text-brand-charcoal mt-2 leading-relaxed font-medium">
                Designing promotional posters for <span className="font-bold text-brand-heading">{project.name}</span> using standard Wise and editorial styles.
              </p>
            </div>

            {/* Quick specifications display */}
            <div className="space-y-3 bg-white p-4 rounded-2xl border border-brand-border/10">
              <span className="text-[9px] font-mono tracking-widest text-brand-forest uppercase font-bold block">SPECIFICATIONS</span>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between items-center py-1 border-b border-brand-fog">
                  <span className="opacity-60">Layout Type</span>
                  <span className="font-bold text-brand-heading font-mono text-[10px] uppercase">
                    {currentPoster?.layoutType || "Hero Showcase"}
                  </span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-brand-fog">
                  <span className="opacity-60">Accent Hue</span>
                  <div className="flex items-center gap-1.5 font-mono text-[10px]">
                    <div 
                      className="w-2.5 h-2.5 rounded-full border border-black/10" 
                      style={{ backgroundColor: currentPoster?.colors?.accentColor }}
                    />
                    {currentPoster?.colors?.accentColor || "#9FE870"}
                  </div>
                </div>
                <div className="flex justify-between items-center py-1">
                  <span className="opacity-60">Theme Mode</span>
                  <span className="font-bold text-brand-heading capitalize font-mono text-[10px]">
                    {currentPoster?.appUI?.theme || "dark"} App
                  </span>
                </div>
              </div>
            </div>

            {/* Tips info box */}
            <div className="bg-brand-lime/10 p-4 rounded-2xl border border-brand-lime/20 text-xs space-y-1.5 text-brand-dark-green">
              <div className="flex items-center gap-1.5 font-bold">
                <Info size={13} />
                <span>Quick Tip</span>
              </div>
              <p className="leading-relaxed text-[11px] opacity-90">
                You can toggle <span className="font-bold">Interactive Edit</span> and click straight on the headlines inside the mockup phone to change poster text dynamically!
              </p>
            </div>

            {/* Neno AI Image Generator */}
            <div className={`p-4.5 rounded-[24px] border space-y-4 transition-all duration-500 shadow-lg ${
              nenoMood === "creative" ? "bg-gradient-to-br from-brand-forest to-slate-900 border-brand-lime/30 text-white" :
              nenoMood === "hyperactive" ? "bg-gradient-to-br from-purple-950 via-slate-950 to-pink-950 border-pink-500/40 text-white" :
              nenoMood === "cyberpunk" ? "bg-gradient-to-br from-cyan-950 via-slate-950 to-blue-950 border-cyan-400/40 text-white" :
              "bg-gradient-to-br from-amber-950 via-slate-950 to-rose-950 border-orange-500/40 text-white"
            }`}>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1.5 font-bold">
                  <div className={`w-2.5 h-2.5 rounded-full animate-ping ${
                    nenoMood === "creative" ? "bg-brand-lime" :
                    nenoMood === "hyperactive" ? "bg-pink-400" :
                    nenoMood === "cyberpunk" ? "bg-cyan-400" : "bg-orange-400"
                  }`} />
                  <span className="uppercase font-display tracking-wider text-[11px] font-black">
                    ⚡ NENO AI GENERATOR
                  </span>
                </div>
                
                {/* Mood Badge status */}
                <span className={`text-[8.5px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                  nenoMood === "creative" ? "bg-brand-lime/20 text-brand-lime" :
                  nenoMood === "hyperactive" ? "bg-pink-500/20 text-pink-400 animate-pulse" :
                  nenoMood === "cyberpunk" ? "bg-cyan-500/20 text-cyan-400 border border-cyan-400/30" : 
                  "bg-orange-500/20 text-orange-400"
                }`}>
                  {nenoMood} Mode
                </span>
              </div>

              <p className="text-[10px] text-white/80 leading-relaxed">
                Generate high-fidelity vector screen assets. Select Neno's mood to alter the design personality and colors!
              </p>

              {/* Interactive Mood Selector Buttons */}
              <div className="space-y-1.5">
                <span className="text-[8px] font-mono font-bold tracking-widest text-white/40 block uppercase">
                  SET NENO'S CREATIVE MOOD:
                </span>
                <div className="grid grid-cols-4 gap-1">
                  {(["creative", "hyperactive", "cyberpunk", "retro"] as const).map((mood) => {
                    const isActive = nenoMood === mood;
                    return (
                      <button
                        key={mood}
                        onClick={() => setNenoMood(mood)}
                        className={`py-1 px-1 text-[8.5px] font-mono font-black rounded-lg uppercase tracking-tight text-center transition-all duration-300 transform active:scale-95 cursor-pointer ${
                          isActive
                            ? mood === "creative" ? "bg-brand-lime text-brand-forest shadow-[0_0_10px_rgba(159,232,112,0.4)]" :
                              mood === "hyperactive" ? "bg-pink-500 text-white shadow-[0_0_10px_rgba(236,72,153,0.4)]" :
                              mood === "cyberpunk" ? "bg-cyan-400 text-slate-950 shadow-[0_0_10px_rgba(34,211,238,0.4)]" :
                              "bg-orange-500 text-white shadow-[0_0_10px_rgba(249,115,22,0.4)]"
                            : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                        }`}
                      >
                        {mood === "creative" ? "🎨 Art" :
                         mood === "hyperactive" ? "⚡ Wild" :
                         mood === "cyberpunk" ? "🦾 Neon" : "📻 VHS"}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Input and generate buttons */}
              <div className="space-y-2 pt-1">
                <div className="relative">
                  <input
                    type="text"
                    placeholder={
                      nenoMood === "creative" ? "Describe pastel minimal graphics..." :
                      nenoMood === "hyperactive" ? "Describe crazy liquid shapes..." :
                      nenoMood === "cyberpunk" ? "Describe bright glowing analytics HUD..." :
                      "Describe 80s synthwave grids..."
                    }
                    value={vectorPrompt}
                    onChange={(e) => setVectorPrompt(e.target.value)}
                    className="w-full bg-white/10 border border-white/10 rounded-xl pl-3 pr-8 py-2 text-[11px] text-white placeholder-white/35 focus:outline-none focus:ring-1 focus:ring-current transition-all font-mono"
                    style={{
                      borderColor: nenoMood === "creative" ? "#9FE870" :
                                   nenoMood === "hyperactive" ? "#EC4899" :
                                   nenoMood === "cyberpunk" ? "#22D3EE" : "#F97316"
                    }}
                  />
                  {vectorPrompt && (
                    <button 
                      onClick={() => setVectorPrompt("")}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white text-[10px]"
                    >
                      ✕
                    </button>
                  )}
                </div>

                <button
                  onClick={async () => {
                    if (!vectorPrompt.trim()) return;
                    setIsGeneratingVector(true);
                    setVectorGenerationMessage(`🍳 NENO is cooking your ${nenoMood} asset...`);
                    try {
                      const res = await fetch("/api/generate-image", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ prompt: `${vectorPrompt} (style: ${nenoMood}, flat dashboard UI illustration vector graphics, beautiful color palette)` })
                      });
                      const data = await res.json();
                      if (data && data.imageUrl) {
                        const updatedPosters = [...project.posters];
                        if (updatedPosters[selectedPosterIndex]) {
                          updatedPosters[selectedPosterIndex] = {
                            ...updatedPosters[selectedPosterIndex],
                            appUI: {
                              ...updatedPosters[selectedPosterIndex].appUI,
                              generatedImage: data.imageUrl
                            }
                          };
                          onUpdateProject({
                            ...project,
                            posters: updatedPosters
                          });
                          setVectorGenerationMessage("⭐ Successfully injected into phone!");
                        } else {
                          setVectorGenerationMessage("❌ Select a poster layout first.");
                        }
                      } else {
                        throw new Error("No image generated.");
                      }
                    } catch (err) {
                      console.error(err);
                      setVectorGenerationMessage("⚠️ Render error. Injected default asset.");
                    } finally {
                      setIsGeneratingVector(false);
                      setTimeout(() => setVectorGenerationMessage(""), 4000);
                    }
                  }}
                  disabled={isGeneratingVector || !vectorPrompt.trim()}
                  className={`w-full text-xs font-black font-display py-2.5 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 transform active:scale-98 shadow-md cursor-pointer ${
                    nenoMood === "creative" ? "bg-brand-lime text-brand-forest hover:bg-brand-lime/90 hover:shadow-[0_0_15px_rgba(159,232,112,0.5)]" :
                    nenoMood === "hyperactive" ? "bg-pink-500 text-white hover:bg-pink-400 hover:shadow-[0_0_15px_rgba(236,72,153,0.5)]" :
                    nenoMood === "cyberpunk" ? "bg-cyan-400 text-slate-950 hover:bg-cyan-300 hover:shadow-[0_0_15px_rgba(34,211,238,0.5)] animate-pulse" :
                    "bg-orange-500 text-white hover:bg-orange-400 hover:shadow-[0_0_15px_rgba(249,115,22,0.5)]"
                  } disabled:opacity-30 disabled:pointer-events-none`}
                >
                  {isGeneratingVector ? (
                    <RefreshCw size={13} className="animate-spin text-current" />
                  ) : (
                    <Sparkles size={13} />
                  )}
                  <span className="uppercase tracking-widest text-[10px]">
                    {isGeneratingVector ? "Cooking visual..." : "✨ Let Neno Cook!"}
                  </span>
                </button>
              </div>

              {vectorGenerationMessage && (
                <div className={`text-[9.5px] font-mono font-bold text-center py-1.5 bg-black/40 rounded-xl border border-white/5 animate-bounce ${
                  nenoMood === "creative" ? "text-brand-lime" :
                  nenoMood === "hyperactive" ? "text-pink-400" :
                  nenoMood === "cyberpunk" ? "text-cyan-400" : "text-orange-400"
                }`}>
                  {vectorGenerationMessage}
                </div>
              )}
            </div>
          </div>
          ) : (
            <div className="space-y-6">
              <div>
                <span className="text-[10px] font-mono tracking-wider font-semibold opacity-60 uppercase block">MULTI-IMAGE CONSOLE</span>
                <p className="text-xs text-brand-charcoal mt-2 leading-relaxed font-medium">
                  Use Neno AI to generate beautiful background textures and mockups. Every prompt produces 3 independent designs.
                </p>
              </div>

              {/* Neno Personality AI Mood Selector */}
              <div className="bg-brand-forest text-white p-4.5 rounded-3xl space-y-3.5 relative overflow-hidden shadow-md">
                <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-xl pointer-events-none" />
                
                <div className="flex items-center gap-1.5">
                  <Sparkles size={14} className="text-brand-lime animate-pulse" />
                  <span className="text-[10px] font-mono tracking-widest text-brand-lime uppercase font-black">
                    NENO PERSONALITY ENGINE
                  </span>
                </div>

                <p className="text-[10px] text-white/80 leading-relaxed font-medium">
                  Altering Neno's personality affects the visual tone of the 3x parallel pipelines.
                </p>

                {/* Interactive Mood Selector Buttons */}
                <div className="space-y-1.5">
                  <span className="text-[8px] font-mono font-bold tracking-widest text-white/40 block uppercase">
                    CURRENT SYSTEM VOICE:
                  </span>
                  <div className="grid grid-cols-4 gap-1">
                    {(["creative", "hyperactive", "cyberpunk", "retro"] as const).map((mood) => {
                      const isActive = nenoMood === mood;
                      return (
                        <button
                          key={mood}
                          onClick={() => setNenoMood(mood)}
                          className={`py-1.5 px-0.5 text-[8.5px] font-mono font-black rounded-lg uppercase tracking-tight text-center transition-all duration-300 transform active:scale-95 cursor-pointer ${
                            isActive
                              ? mood === "creative" ? "bg-brand-lime text-brand-forest shadow-[0_0_10px_rgba(159,232,112,0.4)]" :
                                mood === "hyperactive" ? "bg-pink-500 text-white shadow-[0_0_10px_rgba(236,72,153,0.4)]" :
                                mood === "cyberpunk" ? "bg-cyan-400 text-slate-950 shadow-[0_0_10px_rgba(34,211,238,0.4)]" :
                                "bg-orange-500 text-white shadow-[0_0_10px_rgba(249,115,22,0.4)]"
                              : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white"
                          }`}
                        >
                          {mood === "creative" ? "🎨 Art" :
                           mood === "hyperactive" ? "⚡ Wild" :
                           mood === "cyberpunk" ? "🦾 Neon" : "📻 VHS"}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Wallpaper settings panel inside sidebar */}
              <div className="space-y-3 bg-white p-4 rounded-2xl border border-brand-border/10 text-xs">
                <span className="text-[9px] font-mono tracking-widest text-brand-forest uppercase font-bold block">IMMERSIVE PREVIEW</span>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="opacity-60 font-medium">Show App UI Overlay</span>
                    <button 
                      onClick={() => setShowAppOverlay(!showAppOverlay)}
                      className={`w-9 h-5 rounded-full p-0.5 transition-colors duration-300 focus:outline-none flex items-center ${
                        showAppOverlay ? "bg-brand-forest justify-end" : "bg-gray-300 justify-start"
                      }`}
                    >
                      <div className="w-4 h-4 rounded-full bg-white shadow-md animate-pulse" />
                    </button>
                  </div>

                  <div className="pt-2 border-t border-brand-fog flex justify-between items-center text-[10px]">
                    <span className="opacity-60">Mockup Image Status</span>
                    <span className="font-bold text-brand-forest uppercase font-mono">
                      {selectedSkinImage ? "CUSTOM" : "STANDARD"}
                    </span>
                  </div>
                </div>
              </div>

              {/* Premium Luxury Apple Showcase custom preset card */}
              <div className="bg-amber-50 border border-amber-200 p-4 rounded-3xl space-y-3 relative overflow-hidden shadow-sm">
                <div className="absolute -top-10 -right-10 w-24 h-24 bg-amber-400/10 rounded-full blur-xl pointer-events-none" />
                
                <div className="flex justify-between items-center">
                  <span className="text-[9px] font-mono tracking-widest text-amber-800 uppercase font-bold bg-amber-200/50 px-2 py-0.5 rounded-full inline-block">
                    ★ USER SIGNATURE PRESET
                  </span>
                  <span className="text-[10px] font-bold text-amber-800">8K Render</span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-xs font-black font-display text-amber-950 uppercase tracking-tight">
                    🍎 LUXURY APPLE UI SHOWCASE
                  </h4>
                  <p className="text-[10px] text-amber-900/80 leading-relaxed font-medium">
                    Generates photorealistic premium device portfolios resembling high-end Dribbble & Behance. Features soft studio lighting, dynamic 3D angles, matte titanium frame & 35mm depth of field.
                  </p>
                </div>

                <button
                  onClick={() => handleBotSubmit("Generate a premium Apple-inspired mobile UI showcase. The image should feel like a luxury design agency portfolio, similar to high-end Dribbble and Behance presentations. Composition: Floating iPhone mockup, Dynamic perspective, Large amount of negative space, Clean modern composition, Hero object only. Camera: 35mm product photography, Slight wide-angle, Dramatic perspective, Cinematic framing, Soft depth of field. Lighting: Soft studio lighting, Diffused shadows, Global illumination, Premium reflections, Matte aluminum frame, Clean glossy screen. Background: Minimal studio backdrop, soft cream/gray, No clutter. UI: Modern layout, Large typography, Apple Human Interface inspired, Orange / Black / White color palette. Design Language: Swiss Editorial, Modern branding. Render: Octane photorealistic 8K render, extremely sharp, cinematic lighting.")}
                  disabled={isBotGenerating}
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white font-mono font-extrabold text-[10px] tracking-wider py-2 rounded-xl uppercase transition-all duration-300 transform active:scale-98 cursor-pointer shadow-xs"
                >
                  ⚡ Trigger Ultra-Realistic Render
                </button>
              </div>

              {/* Predefined prompt helpers for the image generator */}
              <div className="space-y-3">
                <span className="text-[9px] font-mono tracking-widest text-brand-charcoal/60 uppercase font-bold block">DESIGN STYLE TAGS</span>
                <div className="flex flex-col gap-1.5">
                  {[
                    { label: "Glassmorphic Cards", prompt: "glowing translucent glassmorphism dashboard cards" },
                    { label: "Teal Neon Analytics", prompt: "teal and cyan glowing futuristic fintech dashboard analytics graph" },
                    { label: "Pastel Wave Minimal", prompt: "warm pastel fluid organic gradient background with subtle gold threads" },
                    { label: "Cyberpunk Tech Grid", prompt: "glowing violet synthwave matrix grid landscape" },
                    { label: "Editorial Bauhaus", prompt: "abstract Swiss Bauhaus geometrical shapes, minimalist sand theme" }
                  ].map((preset, idx) => (
                    <button 
                      key={idx}
                      onClick={() => handleBotSubmit(preset.prompt)}
                      disabled={isBotGenerating}
                      className="w-full text-left p-2.5 rounded-xl border border-brand-border/5 hover:border-brand-forest bg-white hover:bg-brand-fog/20 transition-all text-[11px] font-medium text-brand-charcoal hover:text-brand-heading truncate cursor-pointer"
                    >
                      ✨ {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tips info box */}
              <div className="bg-brand-lime/10 p-4 rounded-2xl border border-brand-lime/20 text-xs space-y-1.5 text-brand-dark-green">
                <div className="flex items-center gap-1.5 font-bold">
                  <Info size={13} />
                  <span>3x Generation Mode</span>
                </div>
                <p className="leading-relaxed text-[11px] opacity-90">
                  Every chat message triggers three parallel creative pipelines. Applying an image layers it cleanly inside the device screen frame.
                </p>
              </div>
            </div>
          )}

          <div className="pt-6 border-t border-brand-border/10 text-[10px] font-mono text-brand-charcoal/50">
            APP/4 Composition Engine v1.0 <br />
            Powered by Gemini-3.5-flash
          </div>
        </aside>

        {/* PANEL 2: ChatGPT-style Chat Workspace (Center, col-span-5) */}
        <section className="lg:col-span-5 flex flex-col justify-between border-r border-brand-border/10 bg-white h-full relative overflow-hidden">
          
          {workspaceMode === "poster" ? (
            <>
              {/* Chat Messages Stream */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
                {messages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"} max-w-full`}
                  >
                    {/* Bubble Container */}
                    <div className="max-w-[90%] md:max-w-[85%] space-y-2">
                      <div 
                        className={`px-4.5 py-3 rounded-[24px] text-xs leading-relaxed md:text-sm font-medium ${
                          msg.sender === "user" 
                            ? "bg-brand-lime text-brand-forest rounded-tr-xs shadow-xs" 
                            : "bg-brand-fog/40 text-brand-heading rounded-tl-xs"
                        }`}
                        style={{ whiteSpace: "pre-line" }}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[9px] font-mono text-brand-charcoal/40 px-2 block">
                        {msg.timestamp}
                      </span>
                    </div>

                    {/* Accompanied generated variations list block */}
                    {msg.posters && msg.posters.length > 0 && (
                      <div className="w-full mt-4 space-y-4">
                        <span className="text-[10px] font-mono font-bold tracking-widest text-brand-forest uppercase px-1 block">
                          CHOOSE A DESIGN STYLE TO ACTIVE PREVIEW
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {msg.posters.map((post, postIdx) => {
                            const isSelected = selectedPosterIndex === postIdx;
                            const isBookmarked = favorites.includes(postIdx);
                            
                            return (
                              <div
                                key={postIdx}
                                onClick={() => handleSelectPoster(postIdx)}
                                className={`p-3.5 rounded-2xl border text-left cursor-pointer transition-all duration-300 relative group flex flex-col justify-between h-[155px] ${
                                  isSelected 
                                    ? "bg-brand-forest border-brand-forest text-white shadow-lg scale-[1.02]" 
                                    : "bg-white hover:bg-brand-fog/20 border-brand-border/10 text-brand-heading hover:border-brand-forest/20"
                                }`}
                              >
                                <div className="space-y-1.5">
                                  <div className="flex justify-between items-center">
                                    <span 
                                      className={`text-[8px] font-bold font-mono tracking-widest px-1.5 py-0.5 rounded-sm uppercase ${
                                        isSelected ? "bg-brand-lime text-brand-forest" : "bg-brand-lime/20 text-brand-forest"
                                      }`}
                                    >
                                      Style {postIdx + 1}
                                    </span>
                                    <button
                                      onClick={(e) => handleToggleFavorite(postIdx, e)}
                                      className={`p-1 rounded-full transition-colors ${
                                        isSelected ? "hover:bg-white/10" : "hover:bg-black/5"
                                      }`}
                                    >
                                      <Heart 
                                        size={12} 
                                        className={`${isBookmarked ? "fill-brand-error text-brand-error" : isSelected ? "text-white/40" : "text-brand-charcoal/30"}`} 
                                      />
                                    </button>
                                  </div>
                                  <h5 className="font-bold text-xs font-display uppercase tracking-tight leading-tight line-clamp-2">
                                    {post.title}
                                  </h5>
                                  <p className={`text-[9.5px] leading-tight line-clamp-3 opacity-80 ${isSelected ? "text-brand-fog" : "text-brand-charcoal"}`}>
                                    {post.promptDescription}
                                  </p>
                                </div>

                                <div className="pt-2 border-t border-brand-border/5 flex justify-between items-center text-[8.5px] font-mono">
                                  <span className="capitalize">{post.layoutType}</span>
                                  <span className={isSelected ? "text-brand-lime" : "text-brand-forest"}>
                                    {isSelected ? "Active ✓" : "Preview"}
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ))}

                {/* Simulated interactive loading timeline */}
                {isGenerating && (
                  <div id="inline-progress-loader" className="flex flex-col items-start space-y-3 p-5 rounded-[24px] bg-brand-forest text-white shadow-xl animate-pulse">
                    <div className="flex items-center gap-2">
                      <RefreshCw size={14} className="animate-spin text-brand-lime" />
                      <span className="text-[11px] font-mono tracking-wider text-brand-lime uppercase font-bold">
                        AI WORKER TIMELINE ({generationProgress}%)
                      </span>
                    </div>
                    
                    {/* Horizontal Progress Bar */}
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden relative shadow-inner">
                      <div 
                        className="h-full bg-brand-lime rounded-full shadow-[0_0_8px_rgba(159,232,112,0.5)] transition-all duration-300"
                        style={{ width: `${generationProgress}%` }}
                      />
                    </div>

                    <div className="flex justify-between w-full text-[10px] font-mono opacity-80">
                      <span>{generationStageText}</span>
                      <span>Generating 3 variations</span>
                    </div>
                  </div>
                )}

                <div ref={chatEndRef} />
              </div>

              {/* Prompt Suggestions Bar */}
              {!isGenerating && messages.length <= 1 && (
                <div className="px-4 py-3 border-t border-brand-border/10 bg-brand-fog/10 space-y-2">
                  <span className="text-[9px] font-mono font-bold tracking-widest text-brand-forest/60 uppercase block">
                    SUGGESTED CREATIVE CONSTRUCTS
                  </span>
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
                    {PROMPT_SUGGESTIONS.map((sug, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleGenerate(sug)}
                        className="flex-shrink-0 px-3.5 py-2 rounded-full border border-brand-border/15 bg-white text-brand-charcoal text-[11px] hover:border-brand-forest/30 hover:bg-brand-fog/40 transition-all cursor-pointer"
                      >
                        {sug}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* ChatGPT-style Input Box Area */}
              <div className="p-4 border-t border-brand-border/10 bg-white">
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleGenerate(inputPrompt);
                  }}
                  className="flex items-center gap-2 bg-brand-forest rounded-full p-2 pl-4 pr-2 shadow-lg relative group transition-all"
                >
                  <input 
                    type="text" 
                    value={inputPrompt}
                    onChange={(e) => setInputPrompt(e.target.value)}
                    placeholder="Describe your app advertisement (e.g., 'vibrant gradients, lime assets'...)"
                    disabled={isGenerating}
                    className="flex-1 bg-transparent border-none text-white text-xs md:text-sm focus:outline-none placeholder:text-white/40 font-medium py-1"
                  />
                  
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      title="Voice Input (Mic)"
                      className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <Mic size={15} />
                    </button>
                    <button
                      type="button"
                      title="Upload Logo asset"
                      className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <ImageIcon size={15} />
                    </button>
                    <button 
                      type="submit"
                      disabled={!inputPrompt.trim() || isGenerating}
                      className="p-2.5 rounded-full bg-brand-lime text-brand-forest hover:scale-[1.05] disabled:scale-100 disabled:opacity-40 disabled:hover:scale-100 transition-all cursor-pointer flex items-center justify-center"
                    >
                      <Send size={14} className="stroke-[2.5]" />
                    </button>
                  </div>
                </form>
              </div>
            </>
          ) : (
            <>
              {/* Chat Messages Stream for Image Bot */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
                {botMessages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"} max-w-full`}
                  >
                    {/* Bubble Container */}
                    <div className="max-w-[90%] md:max-w-[85%] space-y-2">
                      <div 
                        className={`px-4.5 py-3 rounded-[24px] text-xs leading-relaxed md:text-sm font-medium ${
                          msg.sender === "user" 
                            ? "bg-brand-lime text-brand-forest rounded-tr-xs shadow-xs" 
                            : "bg-brand-fog/40 text-brand-heading rounded-tl-xs"
                        }`}
                        style={{ whiteSpace: "pre-line" }}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[9px] font-mono text-brand-charcoal/40 px-2 block">
                        {msg.timestamp}
                      </span>
                    </div>

                    {/* Render the 3 Image outputs generated simultaneously! */}
                    {msg.images && msg.images.length > 0 && (
                      <div className="w-full mt-4 space-y-3">
                        <span className="text-[10px] font-mono font-bold tracking-widest text-brand-forest uppercase px-1 block">
                          ⚡ 3 Parallel Creative Workers Generated:
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {msg.images.map((imgUrl, imgIdx) => {
                            const isSelected = selectedSkinImage === imgUrl;
                            return (
                              <div 
                                key={imgIdx}
                                className={`p-2.5 rounded-2xl bg-white border transition-all duration-300 relative group flex flex-col justify-between h-[285px] ${
                                  isSelected 
                                    ? "border-brand-forest ring-2 ring-brand-lime shadow-md scale-[1.02]" 
                                    : "border-brand-border/10 hover:border-brand-forest/40"
                                }`}
                              >
                                <div className="relative w-full h-[125px] rounded-xl overflow-hidden bg-brand-fog">
                                  <img 
                                    src={imgUrl} 
                                    alt={`Variation ${imgIdx + 1}`} 
                                    className={`w-full h-full object-cover transition-all duration-500 ${
                                      upscaledImages.includes(imgUrl) ? "contrast-[1.05] brightness-[1.02] saturate-[1.02]" : ""
                                    }`}
                                    referrerPolicy="no-referrer"
                                  />
                                  {isSelected && (
                                    <div className="absolute top-2 right-2 bg-brand-forest text-brand-lime p-1 rounded-full shadow-md z-10">
                                      <Check size={10} className="stroke-[3]" />
                                    </div>
                                  )}
                                  
                                  {/* Upscaled Status Badge */}
                                  {upscaledImages.includes(imgUrl) && (
                                    <div className="absolute top-2 left-2 bg-amber-500 text-white font-mono font-black text-[7px] tracking-widest px-1.5 py-0.5 rounded-sm shadow-md animate-bounce">
                                      4X HD ✓
                                    </div>
                                  )}

                                  {/* Upscale Loading Overlay */}
                                  {upscalingImageUrl === imgUrl && (
                                    <div className="absolute inset-0 bg-black/75 backdrop-blur-xs flex flex-col items-center justify-center p-2 text-center space-y-1 z-20">
                                      <RefreshCw size={14} className="animate-spin text-amber-400" />
                                      <span className="text-[9px] font-mono font-bold text-amber-400 uppercase tracking-widest">
                                        Improving {upscaleProgress}%
                                      </span>
                                      <div className="w-16 h-1 bg-white/20 rounded-full overflow-hidden">
                                        <div className="h-full bg-amber-400" style={{ width: `${upscaleProgress}%` }} />
                                      </div>
                                    </div>
                                  )}

                                  <span className="absolute bottom-2 left-2 bg-black/65 backdrop-blur-md text-[8.5px] font-mono text-white px-2 py-0.5 rounded-full">
                                    Pipeline {String.fromCharCode(65 + imgIdx)}
                                  </span>
                                </div>

                                <div className="space-y-1 pt-1.5">
                                  <button
                                    onClick={() => setSelectedSkinImage(imgUrl)}
                                    className={`w-full py-1 rounded-lg text-[9.5px] font-black uppercase tracking-tight flex items-center justify-center gap-1 transition-all cursor-pointer ${
                                      isSelected 
                                        ? "bg-brand-forest text-brand-lime" 
                                        : "bg-brand-lime/10 text-brand-forest hover:bg-brand-lime/20"
                                    }`}
                                  >
                                    <span>📱 View on Mobile Skin</span>
                                  </button>
                                  
                                  <a
                                    href={imgUrl}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="w-full py-0.5 rounded-md text-[8.5px] font-bold text-center text-brand-charcoal hover:text-brand-heading block border border-brand-border/10 hover:bg-brand-fog/40 transition-all"
                                  >
                                    📥 Save Raw Image
                                  </a>

                                  {/* Interactive 4x Image Improve / Upscaler */}
                                  {upscaledImages.includes(imgUrl) ? (
                                    <div className="w-full py-1 rounded-md text-[8.5px] font-mono font-black text-center text-amber-700 bg-amber-100 border border-amber-300 flex items-center justify-center gap-1">
                                      <span>★ 4x Improved HD ✓</span>
                                    </div>
                                  ) : (
                                    <button
                                      type="button"
                                      disabled={upscalingImageUrl !== null}
                                      onClick={() => handleUpscaleImage(imgUrl)}
                                      className={`w-full py-1 rounded-md text-[8.5px] font-bold text-center transition-all flex items-center justify-center gap-1 cursor-pointer border ${
                                        upscalingImageUrl === imgUrl
                                          ? "bg-amber-50 text-amber-500 border-amber-200"
                                          : "text-amber-700 hover:text-amber-800 bg-amber-50 hover:bg-amber-100/70 border-amber-200/50"
                                      }`}
                                    >
                                      <span>✨ image or 4 Times improve</span>
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ))}

                {/* Bot Simulated interactive loading timeline */}
                {isBotGenerating && (
                  <div id="inline-bot-progress-loader" className="flex flex-col items-start space-y-3 p-5 rounded-[24px] bg-brand-forest text-white shadow-xl animate-pulse">
                    <div className="flex items-center gap-2">
                      <RefreshCw size={14} className="animate-spin text-brand-lime" />
                      <span className="text-[11px] font-mono tracking-wider text-brand-lime uppercase font-bold">
                        NENO MULTI-RENDER WORKER ({botGenerationProgress}%)
                      </span>
                    </div>
                    
                    {/* Horizontal Progress Bar */}
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden relative shadow-inner">
                      <div 
                        className="h-full bg-brand-lime rounded-full shadow-[0_0_8px_rgba(159,232,112,0.5)] transition-all duration-300"
                        style={{ width: `${botGenerationProgress}%` }}
                      />
                    </div>

                    <div className="flex justify-between w-full text-[10px] font-mono opacity-80">
                      <span>{botStageText}</span>
                      <span>Generating 3 variations</span>
                    </div>
                  </div>
                )}

                <div ref={chatEndRef} />
              </div>

              {/* Bot Suggestions bar */}
              {!isBotGenerating && botMessages.length <= 1 && (
                <div className="px-4 py-3 border-t border-brand-border/10 bg-brand-fog/10 space-y-2">
                  <span className="text-[9px] font-mono font-bold tracking-widest text-brand-forest/60 uppercase block">
                    NENO INTERACTIVE MULTI-PRESETS
                  </span>
                  <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
                    {[
                      "Generate a premium Apple-inspired mobile UI showcase",
                      "Cyberpunk holographic dashboard widget scene",
                      "Pastel papercut geometric background layout",
                      "Ultra premium neon liquid fluid dynamic art",
                      "3D glossy metal crypto assets mockup rendering"
                    ].map((sug, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleBotSubmit(sug)}
                        className="flex-shrink-0 px-3.5 py-2 rounded-full border border-brand-border/15 bg-white text-brand-charcoal text-[11px] hover:border-brand-forest/30 hover:bg-brand-fog/40 transition-all cursor-pointer"
                      >
                        ✨ {sug}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Chat input box area for Bot */}
              <div className="p-4 border-t border-brand-border/10 bg-white">
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleBotSubmit(botInputPrompt);
                  }}
                  className="flex items-center gap-2 bg-brand-forest rounded-full p-2 pl-4 pr-2 shadow-lg relative group transition-all"
                >
                  <input 
                    type="text" 
                    value={botInputPrompt}
                    onChange={(e) => setBotInputPrompt(e.target.value)}
                    placeholder="Describe wallpaper (e.g., 'cyberpunk city, glowing grids'...)"
                    disabled={isBotGenerating}
                    className="flex-1 bg-transparent border-none text-white text-xs md:text-sm focus:outline-none placeholder:text-white/40 font-medium py-1"
                  />
                  
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      title="Voice Input (Mic)"
                      className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <Mic size={15} />
                    </button>
                    <button
                      type="button"
                      title="Upload Style Referrer Image"
                      className="p-2 rounded-full text-white/60 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                    >
                      <ImageIcon size={15} />
                    </button>
                    <button 
                      type="submit"
                      disabled={!botInputPrompt.trim() || isBotGenerating}
                      className="p-2.5 rounded-full bg-brand-lime text-brand-forest hover:scale-[1.05] disabled:scale-100 disabled:opacity-40 disabled:hover:scale-100 transition-all cursor-pointer flex items-center justify-center"
                    >
                      <Send size={14} className="stroke-[2.5]" />
                    </button>
                  </div>
                </form>
              </div>
            </>
          )}

        </section>

        {/* PANEL 3: Live 3D Perspective Mobile Preview & Export controls (Right, col-span-5) */}
        <section className="lg:col-span-5 bg-brand-fog/30 h-full overflow-y-auto flex flex-col justify-between p-4 md:p-6 space-y-6">
          
          {/* Active Preview Phone Container Block */}
          <div className="flex-1 flex flex-col items-center justify-center relative min-h-[450px]">
            {currentPoster ? (
              <div className="w-full flex items-center justify-center">
                <PhoneMockupPreview
                  deviceAngle={deviceAngle}
                  deviceFrame={deviceFrame}
                  shadowOn={shadowOn}
                  reflectionOn={reflectionOn}
                  zoom={zoom}
                  rotate={rotate}
                  posterColors={currentPoster.colors}
                >
                  <PosterRenderer 
                    poster={
                      workspaceMode === "image-bot" && selectedSkinImage
                        ? {
                            ...currentPoster,
                            appUI: {
                              ...currentPoster.appUI,
                              generatedImage: selectedSkinImage
                            }
                          }
                        : currentPoster
                    } 
                    isEditable={workspaceMode === "poster" ? isEditable : false}
                    onChange={handlePosterDetailsChange}
                    hideOverlay={workspaceMode === "image-bot" ? !showAppOverlay : false}
                  />
                </PhoneMockupPreview>
              </div>
            ) : (
              <div className="text-center p-6 bg-white border border-dashed border-brand-border/30 rounded-[24px] max-w-sm">
                <FileImage size={32} className="mx-auto text-brand-charcoal/40 mb-3" />
                <h5 className="font-bold text-sm text-brand-heading">Awaiting AI Generation</h5>
                <p className="text-xs text-brand-charcoal/70 mt-1">
                  Type a design style or prompt suggestion in the chat on the left to spawn gorgeous variations.
                </p>
              </div>
            )}

            {/* Quick angle selector floaters (Top Left Float) */}
            {currentPoster && (
              <div className="absolute top-0 left-0 bg-white border border-brand-border/10 p-2 rounded-2xl shadow-md space-y-1 z-10 flex flex-col items-start">
                <span className="text-[8px] font-mono tracking-wider font-bold opacity-50 px-1">PERSPECTIVE</span>
                <div className="grid grid-cols-2 gap-1 w-full">
                  {(["front", "left", "right", "floating", "landscape", "showcase"] as const).map((ang) => (
                    <button
                      key={ang}
                      onClick={() => setDeviceAngle(ang)}
                      className={`px-2 py-1 rounded-lg text-[9px] font-bold font-mono uppercase tracking-tight text-center transition-all cursor-pointer ${
                        deviceAngle === ang 
                          ? "bg-brand-forest text-brand-lime" 
                          : "bg-brand-fog/50 text-brand-charcoal hover:bg-brand-fog"
                      }`}
                    >
                      {ang}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quick zooming / rotation sliders (Top Right Float) */}
            {currentPoster && (
              <div className="absolute top-0 right-0 bg-white border border-brand-border/10 p-3 rounded-2xl shadow-md space-y-2.5 z-10 w-44 text-left">
                <span className="text-[8px] font-mono tracking-wider font-bold opacity-50 block">CAMERA CONTROLS</span>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[9px] font-mono">
                    <span>Zoom</span>
                    <span className="font-bold">{Math.round(zoom * 100)}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.6" 
                    max="1.4" 
                    step="0.1" 
                    value={zoom}
                    onChange={(e) => setZoom(parseFloat(e.target.value))}
                    className="w-full accent-brand-forest cursor-pointer"
                  />
                </div>
                <div className="space-y-1.5">
                  <div className="flex justify-between text-[9px] font-mono">
                    <span>Rotation</span>
                    <span className="font-bold">{rotate}°</span>
                  </div>
                  <input 
                    type="range" 
                    min="-45" 
                    max="45" 
                    step="5" 
                    value={rotate}
                    onChange={(e) => setRotate(parseInt(e.target.value))}
                    className="w-full accent-brand-forest cursor-pointer"
                  />
                </div>
                <button
                  onClick={() => { setZoom(1.0); setRotate(0); }}
                  className="w-full py-1 bg-brand-fog text-brand-forest font-bold font-mono text-[9px] uppercase tracking-wider rounded-lg hover:bg-brand-border/20 transition-all cursor-pointer"
                >
                  Reset Camera
                </button>
              </div>
            )}
          </div>

          {/* Export & Download Setup Card Panel */}
          {currentPoster && (
            <div className="bg-white p-5 rounded-[24px] border border-brand-border/10 shadow-sm space-y-4">
              <div className="flex items-center gap-2 border-b border-brand-fog pb-3">
                <Sliders size={14} className="text-brand-forest" />
                <h4 className="text-xs font-mono font-bold tracking-widest text-brand-charcoal uppercase">
                  HIGH-DEFINITION EXPORT ENGINE
                </h4>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-left">
                
                {/* Format selection */}
                <div className="space-y-1">
                  <label className="text-[9px] font-mono font-bold text-brand-charcoal uppercase block">Format</label>
                  <select
                    value={downloadFormat}
                    onChange={(e) => setDownloadFormat(e.target.value as any)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl border border-brand-border/15 font-medium bg-brand-fog/20 cursor-pointer"
                  >
                    <option value="png">PNG (Lossless)</option>
                    <option value="jpeg">JPEG (Compact)</option>
                    <option value="webp">WebP (Optimal)</option>
                  </select>
                </div>

                {/* Aspect ratio presets */}
                <div className="space-y-1">
                  <label className="text-[9px] font-mono font-bold text-brand-charcoal uppercase block">Aspect Ratio</label>
                  <select
                    value={downloadRatio}
                    onChange={(e) => setDownloadRatio(e.target.value as any)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl border border-brand-border/15 font-medium bg-brand-fog/20 cursor-pointer"
                  >
                    <option value="story">9:16 Story (1080x1920)</option>
                    <option value="square">1:1 Post (2048x2048)</option>
                    <option value="banner">16:9 Landscape Banner (Billboard)</option>
                    <option value="appstore">5:8 App Store Promo</option>
                  </select>
                </div>

                {/* Resolution Quality size */}
                <div className="space-y-1">
                  <label className="text-[9px] font-mono font-bold text-brand-charcoal uppercase block">Quality</label>
                  <select
                    value={downloadQuality}
                    onChange={(e) => setDownloadQuality(e.target.value as any)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl border border-brand-border/15 font-medium bg-brand-fog/20 cursor-pointer"
                  >
                    <option value="standard">Standard Definition</option>
                    <option value="hd">High Definition (HD)</option>
                    <option value="4k">4K Ultra Resolution</option>
                  </select>
                </div>

                {/* Bezel selection */}
                <div className="space-y-1">
                  <label className="text-[9px] font-mono font-bold text-brand-charcoal uppercase block">Hardware Bezel</label>
                  <select
                    value={deviceFrame}
                    onChange={(e) => setDeviceFrame(e.target.value as any)}
                    className="w-full px-2.5 py-2 text-xs rounded-xl border border-brand-border/15 font-medium bg-brand-fog/20 cursor-pointer"
                  >
                    <option value="black">Black Titanium</option>
                    <option value="white">Silver White</option>
                    <option value="titanium">Natural Gold</option>
                  </select>
                </div>

              </div>

              {/* Extras: shadow and reflection checkboxes */}
              <div className="flex flex-wrap gap-4 items-center pt-1 text-xs">
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={shadowOn} 
                    onChange={(e) => setShadowOn(e.target.checked)}
                    className="rounded-xs border-brand-border/20 text-brand-forest focus:ring-brand-forest cursor-pointer"
                  />
                  <span className="opacity-70 font-medium">3D Hardware Shadows</span>
                </label>
                <label className="flex items-center gap-1.5 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={reflectionOn} 
                    onChange={(e) => setReflectionOn(e.target.checked)}
                    className="rounded-xs border-brand-border/20 text-brand-forest focus:ring-brand-forest cursor-pointer"
                  />
                  <span className="opacity-70 font-medium">Bezel Gloss Glass Sheen</span>
                </label>
              </div>

              {/* Big Export Trigger Button with Neon Glow & Dynamic Playful Labels */}
              <button
                onClick={handleDownloadImage}
                disabled={isDownloading}
                className="w-full py-4 rounded-full bg-brand-forest text-white font-extrabold font-display text-xs tracking-widest uppercase hover:bg-brand-lime hover:text-brand-forest active:scale-[0.97] hover:shadow-[0_0_20px_rgba(159,232,112,0.6)] disabled:opacity-50 disabled:scale-100 transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 border border-transparent hover:border-brand-forest/20 relative overflow-hidden group"
              >
                <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-shimmer" />
                {isDownloading ? (
                  <>
                    <RefreshCw className="animate-spin text-brand-lime" size={14} />
                    <span>🚀 RENDER ENGINE: ASSEMBLING MASTERPIECE...</span>
                  </>
                ) : (
                  <>
                    <Download size={14} className="group-hover:translate-y-0.5 transition-transform" />
                    <span>🔥 DOWNLOAD PRESET ({
                      downloadRatio === "story" ? "9:16 STORY" : 
                      downloadRatio === "square" ? "1:1 SQUARE" : 
                      downloadRatio === "banner" ? "16:9 BANNER" : 
                      "5:8 APP STORE"
                    })</span>
                  </>
                )}
              </button>

              {/* Download Feedback Dialog Message */}
              {downloadCompletedMessage && (
                <div className="p-3 bg-brand-lime/10 border border-brand-lime/20 rounded-xl text-center text-xs font-semibold text-brand-forest flex items-center justify-center gap-1.5">
                  <Check size={14} className="text-brand-forest stroke-[3]" />
                  {downloadCompletedMessage}
                </div>
              )}

            </div>
          )}

        </section>

      </div>

      {/* Premium AI Model Configuration Modal */}
      {isAIModalOpen && (
        <div className="fixed inset-0 bg-brand-heading/60 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-white rounded-[32px] border border-brand-border/10 max-w-md w-full overflow-hidden shadow-2xl p-6 relative">
            <button
              onClick={() => setIsAIModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full hover:bg-brand-fog text-brand-charcoal/60 transition-all cursor-pointer"
            >
              <span className="font-sans font-bold text-lg">✕</span>
            </button>

            <div className="space-y-6">
              <div>
                <span className="text-[10px] font-mono tracking-widest text-brand-forest uppercase font-bold bg-brand-lime/20 px-2.5 py-0.5 rounded-full inline-block">
                  SYSTEM CORE
                </span>
                <h3 className="text-lg font-black font-display text-brand-heading uppercase tracking-tight mt-2">
                  AI Model Configuration
                </h3>
                <p className="text-xs text-brand-charcoal/60 leading-relaxed mt-1">
                  Choose the master intelligence engine for generating advertisement layouts, headlines, and subheaders.
                </p>
              </div>

              {/* Engine Selection cards */}
              <div className="space-y-3">
                <button
                  onClick={() => setAiEngine("gemini")}
                  className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex items-start gap-4 ${
                    aiEngine === "gemini"
                      ? "bg-brand-forest/5 border-brand-forest shadow-xs"
                      : "bg-white border-brand-border/10 hover:bg-brand-fog/50"
                  }`}
                >
                  <div className="p-2 rounded-xl bg-brand-lime/20 text-brand-forest">
                    <Sparkles size={16} />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-extrabold text-brand-heading font-display">GEMINI 3.5 FLASH</h4>
                      {aiEngine === "gemini" && (
                        <span className="text-[9px] font-mono font-bold bg-brand-lime text-brand-forest px-1.5 py-0.5 rounded-md">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-brand-charcoal/60 leading-relaxed mt-1">
                      Native multimodal agent designed for ultra-fast vector layout compositions and high-fidelity specs.
                    </p>
                  </div>
                </button>

                <button
                  onClick={() => setAiEngine("openai")}
                  className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer relative overflow-hidden flex items-start gap-4 ${
                    aiEngine === "openai"
                      ? "bg-brand-forest/5 border-brand-forest shadow-xs"
                      : "bg-white border-brand-border/10 hover:bg-brand-fog/50"
                  }`}
                >
                  <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
                    <Sparkles size={16} />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-sm font-extrabold text-brand-heading font-display">GPT-4O-MINI</h4>
                      {aiEngine === "openai" && (
                        <span className="text-[9px] font-mono font-bold bg-emerald-800 text-white px-1.5 py-0.5 rounded-md">
                          ACTIVE
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-brand-charcoal/60 leading-relaxed mt-1">
                      Advanced linguistic model from OpenAI. Excellent for hyper-catchy marketing slogans and features.
                    </p>
                  </div>
                </button>
              </div>

              {/* Secure Credentials Info Panel */}
              <div className="p-4 bg-brand-fog rounded-2xl border border-brand-border/5 space-y-2">
                <span className="text-[9px] font-mono font-bold text-brand-forest uppercase tracking-wider block">
                  🛡️ SECURITY REGISTRY
                </span>
                <p className="text-[10px] text-brand-charcoal/60 leading-relaxed">
                  All developer API keys are locked securely on the container server side and never exposed to the client browser environment.
                </p>
                <div className="text-[9px] font-mono font-bold text-brand-forest flex flex-col gap-1 pt-1 opacity-70">
                  <div className="flex justify-between">
                    <span>Gemini Key Status:</span>
                    <span className="text-emerald-700 font-bold">● CONFIGURED</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ChatGPT Key Status:</span>
                    <span className="text-emerald-700 font-bold">● CONFIGURED</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setIsAIModalOpen(false)}
                className="w-full bg-brand-forest text-white py-3.5 rounded-full font-bold font-display text-xs tracking-widest uppercase hover:bg-brand-forest/90 transition-all cursor-pointer"
              >
                Close Configuration
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
