import { PosterVariation, PosterFeature, AppUIConfig } from "../types";
import { DynamicIcon } from "./DynamicIcon";

interface PosterRendererProps {
  poster: PosterVariation;
  onChange?: (updated: PosterVariation) => void;
  isEditable?: boolean;
  hideOverlay?: boolean;
}

export function PosterRenderer({ poster, onChange, isEditable = false, hideOverlay = false }: PosterRendererProps) {
  const { layoutType, title, subtitle, badgeText, colors, features, appUI } = poster;

  const handleTextChange = (field: "title" | "subtitle" | "badgeText", value: string) => {
    if (onChange) {
      onChange({
        ...poster,
        [field]: value
      });
    }
  };

  const handleUIChange = (updatedUI: Partial<AppUIConfig>) => {
    if (onChange) {
      onChange({
        ...poster,
        appUI: { ...appUI, ...updatedUI }
      });
    }
  };

  // Convert array of bgColors into Tailwind-compatible inline styles
  const bgStyle = {
    background: colors.bgGradientType === "radial"
      ? `radial-gradient(circle at center, ${colors.bgColors.join(", ")})`
      : `linear-gradient(135deg, ${colors.bgColors.join(", ")})`
  };

  // Simulated Mobile App Interface inside the poster
  const renderSimulatedAppScreen = () => {
    const isDarkAppTheme = appUI.theme === "dark";
    return (
      <div 
        id="poster-simulated-app"
        className={`w-[210px] h-[340px] rounded-[32px] p-4 flex flex-col justify-between shadow-2xl relative overflow-hidden transition-all duration-300 border ${
          isDarkAppTheme 
            ? "bg-[#0A0D10]/95 border-[#1F2937]/80 text-white" 
            : "bg-white/95 border-gray-200 text-gray-900"
        }`}
      >
        {/* Dynamic Gemini Vector Graphics Background Overlay */}
        {appUI.generatedImage && (
          <img 
            src={appUI.generatedImage} 
            className="absolute inset-0 w-full h-full object-cover z-0 transition-opacity duration-300 pointer-events-none" 
            referrerPolicy="no-referrer"
            alt="Gemini AI Asset" 
          />
        )}

        {/* Dynamic Island / Speaker notch */}
        <div className="absolute top-1 left-1/2 -translate-x-1/2 w-16 h-3.5 bg-black rounded-full z-10 flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-900/60 ml-auto mr-1" />
        </div>

        {/* Status Bar */}
        <div className="flex justify-between items-center text-[8px] font-mono px-2 pt-0.5 opacity-60 relative z-10">
          <span>09:41</span>
          <div className="flex gap-1 items-center">
            <DynamicIcon name="Activity" size={6} />
            <div className="w-3 h-1.5 border border-current rounded-xs flex items-center p-0.5">
              <div className="h-full w-2 bg-current" />
            </div>
          </div>
        </div>

        {/* Dynamic Overlay Content to keep layout gorgeous */}
        <div className="flex-1 flex flex-col justify-between relative z-10 mt-1.5">
          {!hideOverlay ? (
            <>
              {/* Screen Header */}
              <div className="mt-1 px-1 flex justify-between items-center">
                <div>
                  <span className={`text-[8px] font-medium opacity-60 block ${appUI.generatedImage ? "text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]" : ""}`}>
                    TOTAL PERFORMANCE
                  </span>
                  {isEditable ? (
                    <input 
                      type="text" 
                      value={appUI.screenTitle} 
                      onChange={(e) => handleUIChange({ screenTitle: e.target.value })}
                      className={`text-[11px] font-bold tracking-tight bg-transparent border-b border-transparent hover:border-current focus:border-current outline-none w-24 ${appUI.generatedImage ? "text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]" : ""}`}
                    />
                  ) : (
                    <span className={`text-[11px] font-bold tracking-tight ${appUI.generatedImage ? "text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]" : ""}`}>
                      {appUI.screenTitle}
                    </span>
                  )}
                </div>
                <div className={`p-1 rounded-full ${isDarkAppTheme || appUI.generatedImage ? "bg-black/40 text-white" : "bg-black/5"}`}>
                  <DynamicIcon name="Sparkle" size={10} className="text-brand-lime" />
                </div>
              </div>

              {/* Screen Metrics Area */}
              <div className="my-1 px-1">
                {isEditable ? (
                  <input 
                    type="text" 
                    value={appUI.screenBalance} 
                    onChange={(e) => handleUIChange({ screenBalance: e.target.value })}
                    className="text-xl font-bold tracking-tight font-display bg-transparent border-b border-transparent hover:border-current focus:border-current outline-none w-full"
                  />
                ) : (
                  <span className={`text-xl font-bold tracking-tight font-display block ${appUI.generatedImage ? "text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]" : ""}`} style={{ color: appUI.generatedImage ? "#FFFFFF" : colors.accentColor }}>
                    {appUI.screenBalance}
                  </span>
                )}
              </div>

              {/* Custom sparkline mini graph (Hide if we have generated image to showcase the clean visual art) */}
              {!appUI.generatedImage ? (
                <div className="h-14 w-full relative flex items-end">
                  <svg className="w-full h-full" viewBox="0 0 100 40">
                    <defs>
                      <linearGradient id="chart-glow" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={colors.accentColor} stopOpacity="0.4" />
                        <stop offset="100%" stopColor={colors.accentColor} stopOpacity="0.0" />
                      </linearGradient>
                    </defs>
                    {/* Draw sparkline curve based on chartData */}
                    {appUI.chartData && appUI.chartData.length > 1 && (
                      <>
                        <path
                          d={`M ${appUI.chartData.map((val, idx) => {
                            const stepX = idx * (100 / (appUI.chartData.length - 1));
                            const stepY = 40 - (val / 100) * 32;
                            return `${stepX} ${stepY}`;
                          }).join(" L ")}`}
                          fill="none"
                          stroke={colors.accentColor}
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d={`M 0 40 L ${appUI.chartData.map((val, idx) => {
                            const stepX = idx * (100 / (appUI.chartData.length - 1));
                            const stepY = 40 - (val / 100) * 32;
                            return `${stepX} ${stepY}`;
                          }).join(" L ")} L 100 40 Z`}
                          fill="url(#chart-glow)"
                        />
                      </>
                    )}
                  </svg>
                </div>
              ) : (
                <div className="h-14 flex items-center justify-center bg-black/40 backdrop-blur-xs rounded-xl px-2">
                  <span className="text-[8px] font-mono font-bold text-brand-lime text-center tracking-tight leading-none uppercase">
                    ★ Core Asset Active
                  </span>
                </div>
              )}

              {/* Dynamic transaction / node status list */}
              <div className="flex flex-col gap-1 mt-1">
                {appUI.items && appUI.items.slice(0, appUI.generatedImage ? 1 : 2).map((item, idx) => (
                  <div 
                    key={idx} 
                    className={`flex items-center justify-between p-1.5 rounded-xl text-[9px] ${
                      isDarkAppTheme || appUI.generatedImage ? "bg-black/45 text-white border border-white/5" : "bg-black/5"
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <div 
                        className="p-1 rounded-lg flex items-center justify-center text-white"
                        style={{ backgroundColor: item.color || colors.accentColor }}
                      >
                        <DynamicIcon name={item.icon} size={8} />
                      </div>
                      <span className="font-medium opacity-90 truncate max-w-[85px]">{item.label}</span>
                    </div>
                    <span className="font-bold font-mono" style={{ color: appUI.generatedImage ? "#9FE870" : item.color }}>{item.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col justify-center items-center">
              <span className="text-[10px] font-mono font-black text-white bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full tracking-widest uppercase animate-pulse shadow-sm border border-white/10">
                📱 IMMERSIVE SKIN ACTIVE
              </span>
            </div>
          )}

          {/* Tiny Home Indicator line */}
          <div className="w-16 h-1 bg-current opacity-20 rounded-full mx-auto mt-auto mb-1" />
        </div>
      </div>
    );
  };

  // Helper features footer renderer
  const renderFeaturesList = (flexStyle = "flex-row") => {
    return (
      <div className={`flex gap-4 ${flexStyle} justify-between border-t border-white/10 pt-4 mt-auto w-full`}>
        {features && features.map((feat, idx) => (
          <div key={idx} className="flex gap-2.5 items-start flex-1">
            <div 
              className="p-2 rounded-xl flex items-center justify-center text-black shadow-lg"
              style={{ backgroundColor: colors.accentColor }}
            >
              <DynamicIcon name={feat.iconName} size={16} />
            </div>
            <div className="text-left">
              <h4 className="text-xs font-bold font-display" style={{ color: colors.textColor }}>
                {feat.title.toUpperCase()}
              </h4>
              <p className="text-[10px] leading-relaxed mt-0.5" style={{ color: colors.textMutedColor }}>
                {feat.desc}
              </p>
            </div>
          </div>
        ))}
      </div>
    );
  };

  // Master Layout Selection
  const renderLayoutContent = () => {
    switch (layoutType) {
      case "minimal-editorial":
        return (
          <div className="h-full flex flex-col justify-between p-7 text-left relative z-10">
            {/* Top header block */}
            <div className="space-y-4">
              <div 
                className="inline-block py-1 px-3 rounded-full text-[9px] font-bold font-mono border tracking-widest uppercase"
                style={{ borderColor: `${colors.accentColor}30`, color: colors.accentColor }}
              >
                {badgeText}
              </div>
              
              {isEditable ? (
                <textarea 
                  value={title} 
                  onChange={(e) => handleTextChange("title", e.target.value)}
                  className="w-full text-2xl font-black font-display tracking-tight leading-[1.1] uppercase bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textColor }}
                />
              ) : (
                <h1 className="text-2xl font-black font-display tracking-tight leading-[1.1] uppercase" style={{ color: colors.textColor }}>
                  {title}
                </h1>
              )}

              {isEditable ? (
                <textarea 
                  value={subtitle} 
                  onChange={(e) => handleTextChange("subtitle", e.target.value)}
                  className="w-full text-[11px] leading-relaxed bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={3}
                  style={{ color: colors.textMutedColor }}
                />
              ) : (
                <p className="text-[11px] leading-relaxed" style={{ color: colors.textMutedColor }}>
                  {subtitle}
                </p>
              )}
            </div>

            {/* Left-aligned editorial mockup presentation */}
            <div className="my-5 flex justify-center w-full relative">
              <div className="absolute inset-0 bg-radial from-white/5 to-transparent blur-2xl rounded-full scale-150" />
              <div className="transform rotate-2 hover:rotate-0 transition-transform duration-500 scale-105 z-10">
                {renderSimulatedAppScreen()}
              </div>
            </div>

            {/* Standard stacked features list */}
            {renderFeaturesList("flex-row")}
          </div>
        );

      case "feature-grid":
        return (
          <div className="h-full flex flex-col justify-between p-7 text-left relative z-10">
            {/* Badge & Title */}
            <div className="space-y-3">
              <div 
                className="inline-block py-1 px-2.5 rounded-full text-[8px] font-mono tracking-widest uppercase bg-white/5 border border-white/10"
                style={{ color: colors.accentColor }}
              >
                {badgeText}
              </div>

              {isEditable ? (
                <textarea 
                  value={title} 
                  onChange={(e) => handleTextChange("title", e.target.value)}
                  className="w-full text-2xl font-black font-display tracking-tighter leading-none uppercase bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textColor }}
                />
              ) : (
                <h1 className="text-2xl font-black font-display tracking-tighter leading-none uppercase" style={{ color: colors.textColor }}>
                  {title}
                </h1>
              )}
            </div>

            {/* Simulated bento box layout */}
            <div className="my-4 grid grid-cols-5 gap-3 items-center">
              <div className="col-span-3 transform -rotate-2 scale-[1.02]">
                {renderSimulatedAppScreen()}
              </div>
              
              {/* Floating feature item bento blocks */}
              <div className="col-span-2 flex flex-col gap-3">
                {features && features.map((feat, idx) => (
                  <div 
                    key={idx} 
                    className="p-3 rounded-2xl border border-white/5 bg-white/5 flex flex-col items-start gap-1.5"
                  >
                    <div className="p-1.5 rounded-lg text-black" style={{ backgroundColor: colors.accentColor }}>
                      <DynamicIcon name={feat.iconName} size={12} />
                    </div>
                    <span className="text-[10px] font-bold font-display uppercase tracking-tight" style={{ color: colors.textColor }}>
                      {feat.title}
                    </span>
                    <p className="text-[8.5px] leading-tight" style={{ color: colors.textMutedColor }}>
                      {feat.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-2 mt-auto">
              {isEditable ? (
                <textarea 
                  value={subtitle} 
                  onChange={(e) => handleTextChange("subtitle", e.target.value)}
                  className="w-full text-[10.5px] leading-relaxed bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textMutedColor }}
                />
              ) : (
                <p className="text-[10.5px] leading-relaxed" style={{ color: colors.textMutedColor }}>
                  {subtitle}
                </p>
              )}
              <div className="w-12 h-1 rounded-full bg-white/10" />
            </div>
          </div>
        );

      case "circular-bento":
        return (
          <div className="h-full flex flex-col justify-between p-6 text-left relative z-10">
            {/* Header pill */}
            <div className="flex justify-between items-center w-full">
              <span className="text-[9px] font-bold font-mono tracking-wider opacity-60" style={{ color: colors.textColor }}>
                PREVIEWS & CODES
              </span>
              <div 
                className="py-1 px-3 rounded-full text-[8px] font-mono font-bold border tracking-widest uppercase"
                style={{ borderColor: colors.accentColor, color: colors.accentColor }}
              >
                {badgeText}
              </div>
            </div>

            {/* Core Bento Card */}
            <div className="my-3.5 bg-black/25 rounded-[24px] p-4 border border-white/5 flex flex-col gap-3">
              {isEditable ? (
                <textarea 
                  value={title} 
                  onChange={(e) => handleTextChange("title", e.target.value)}
                  className="w-full text-[19px] font-bold font-display tracking-tight leading-tight uppercase bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textColor }}
                />
              ) : (
                <h2 className="text-[19px] font-bold font-display tracking-tight leading-tight uppercase" style={{ color: colors.textColor }}>
                  {title}
                </h2>
              )}
              
              {isEditable ? (
                <textarea 
                  value={subtitle} 
                  onChange={(e) => handleTextChange("subtitle", e.target.value)}
                  className="w-full text-[10px] leading-relaxed bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textMutedColor }}
                />
              ) : (
                <p className="text-[10px] leading-relaxed" style={{ color: colors.textMutedColor }}>
                  {subtitle}
                </p>
              )}
            </div>

            {/* Floating screen showcase */}
            <div className="my-2.5 flex justify-center w-full">
              <div className="transform hover:scale-105 transition-transform duration-500 scale-[0.93]">
                {renderSimulatedAppScreen()}
              </div>
            </div>

            {/* Features list */}
            {renderFeaturesList("flex-row")}
          </div>
        );

      case "split-promo":
        return (
          <div className="h-full flex flex-col justify-between p-7 text-left relative z-10">
            {/* Split Header */}
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" style={{ color: colors.accentColor }} />
                <span className="text-[9px] font-bold font-mono tracking-widest uppercase" style={{ color: colors.accentColor }}>
                  {badgeText}
                </span>
              </div>

              {isEditable ? (
                <textarea 
                  value={title} 
                  onChange={(e) => handleTextChange("title", e.target.value)}
                  className="w-full text-2xl font-black font-display tracking-tight leading-none uppercase bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textColor }}
                />
              ) : (
                <h1 className="text-2xl font-black font-display tracking-tight leading-none uppercase" style={{ color: colors.textColor }}>
                  {title}
                </h1>
              )}
            </div>

            {/* Screen layout nested cleanly */}
            <div className="my-5 flex justify-center w-full">
              <div className="relative p-1 rounded-[38px] bg-gradient-to-tr from-white/10 to-transparent border border-white/10 shadow-2xl scale-100">
                {renderSimulatedAppScreen()}
              </div>
            </div>

            {/* Bottom Subtitle / Features */}
            <div className="space-y-4">
              {isEditable ? (
                <textarea 
                  value={subtitle} 
                  onChange={(e) => handleTextChange("subtitle", e.target.value)}
                  className="w-full text-[10px] leading-normal bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textMutedColor }}
                />
              ) : (
                <p className="text-[10px] leading-normal" style={{ color: colors.textMutedColor }}>
                  {subtitle}
                </p>
              )}
              {renderFeaturesList("flex-row")}
            </div>
          </div>
        );

      case "hero-showcase":
      default:
        return (
          <div className="h-full flex flex-col justify-between p-7 text-left relative z-10">
            {/* Top Badge */}
            <div className="w-full">
              <span 
                className="inline-block py-1 px-3 rounded-full text-[8.5px] font-mono tracking-widest uppercase font-bold border"
                style={{ borderColor: `${colors.accentColor}40`, color: colors.accentColor }}
              >
                {badgeText}
              </span>
            </div>

            {/* Massive punchy typography */}
            <div className="space-y-3 my-2">
              {isEditable ? (
                <textarea 
                  value={title} 
                  onChange={(e) => handleTextChange("title", e.target.value)}
                  className="w-full text-[25px] font-black font-display tracking-tight leading-[1.05] uppercase bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textColor }}
                />
              ) : (
                <h1 className="text-[25px] font-black font-display tracking-tight leading-[1.05] uppercase" style={{ color: colors.textColor }}>
                  {title}
                </h1>
              )}

              {isEditable ? (
                <textarea 
                  value={subtitle} 
                  onChange={(e) => handleTextChange("subtitle", e.target.value)}
                  className="w-full text-[11px] leading-relaxed bg-transparent border border-transparent hover:border-white/15 focus:border-white/30 rounded p-1 outline-none resize-none"
                  rows={2}
                  style={{ color: colors.textMutedColor }}
                />
              ) : (
                <p className="text-[11px] leading-relaxed" style={{ color: colors.textMutedColor }}>
                  {subtitle}
                </p>
              )}
            </div>

            {/* Centered Smartphone Mockup */}
            <div className="my-4 flex justify-center w-full relative">
              {/* Backdrop glow */}
              <div 
                className="absolute top-12 left-1/2 -translate-x-1/2 w-40 h-40 rounded-full blur-3xl opacity-25"
                style={{ backgroundColor: colors.accentColor }}
              />
              <div className="transform hover:-translate-y-2 hover:rotate-1 transition-all duration-500 scale-[1.03] z-10 shadow-2xl">
                {renderSimulatedAppScreen()}
              </div>
            </div>

            {/* Two Column Features */}
            {renderFeaturesList("flex-row")}
          </div>
        );
    }
  };

  return (
    <div 
      id="poster-wrapper"
      className="w-[360px] h-[640px] rounded-[28px] overflow-hidden relative shadow-2xl border border-white/10 select-none flex flex-col justify-between transition-all duration-300 group"
      style={bgStyle}
    >
      {/* Soft overlay patterns or glowing grids */}
      <div className="absolute inset-0 bg-[radial-gradient(#ffffff03_1px,transparent_1px)] [background-size:16px_16px] opacity-60 z-0" />
      <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full blur-3xl opacity-15 pointer-events-none" style={{ backgroundColor: colors.accentColor }} />
      <div className="absolute -bottom-12 -right-12 w-48 h-48 rounded-full blur-3xl opacity-10 pointer-events-none" style={{ backgroundColor: colors.accentColor }} />

      {/* Render the selected layout content */}
      {renderLayoutContent()}
    </div>
  );
}
