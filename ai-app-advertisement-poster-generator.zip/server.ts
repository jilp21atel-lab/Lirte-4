import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini client
let aiClient: GoogleGenAI | null = null;
const DEFAULT_GEMINI_KEY = "AIzaSyBmYbvoSSKwVRb4v5xKLJiMBPgovg7jo_Y";
const DEFAULT_OPENAI_KEY = "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";

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY || DEFAULT_GEMINI_KEY;
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Fallback high-fidelity poster generator if API key is missing or fails
function getMockPosterVariations(appName: string, appCategory: string, userPrompt: string, themeStyle: string) {
  const name = appName || "Appify";
  const cat = appCategory || "Utility";
  
  // Create 3 beautiful mock variations with different premium visual identities
  return [
    {
      layoutType: "hero-showcase",
      title: `${name.toUpperCase()}: THE FUTURE IS NOW.`,
      subtitle: `The ultimate ${cat.toLowerCase()} platform built to stream-line your entire workflow, powered by secure automated tools.`,
      badgeText: "★ PREMIUM APP OF THE YEAR",
      colors: {
        bgGradientType: "linear",
        bgColors: ["#0B1500", "#1B3B06", "#0B1500"], // Forest theme inspired by Wise
        accentColor: "#9FE870", // Lime accent
        textColor: "#FFFFFF",
        textMutedColor: "#C3D2B8"
      },
      features: [
        { iconName: "Zap", title: "Instant Access", desc: "No delays, absolute efficiency right at your fingertips." },
        { iconName: "Shield", title: "Bank-Grade Security", desc: "Your metrics and operations are fully guarded." }
      ],
      appUI: {
        screenTitle: "Overview",
        screenBalance: "99.8% Efficiency",
        chartData: [20, 35, 45, 30, 60, 75, 90],
        theme: "dark",
        items: [
          { label: "Active Nodes", value: "8 Active", icon: "Activity", color: "#9FE870" },
          { label: "Data Pipeline", value: "Optimal", icon: "Check", color: "#9FE870" }
        ]
      },
      promptDescription: "A minimalist wise-inspired dark forest theme centering on bold typography, ample whitespace, and vivid lime accents."
    },
    {
      layoutType: "minimal-editorial",
      title: "SIMPLICITY IN EVERY ACTION.",
      subtitle: `Discover how the ${cat.toLowerCase()} layout of ${name} simplifies complex day-to-day operations with beautiful metrics.`,
      badgeText: "EDITORS' CHOICE 2026",
      colors: {
        bgGradientType: "linear",
        bgColors: ["#0E0F0C", "#262B24", "#121411"],
        accentColor: "#F59E0B", // Vibrant Orange
        textColor: "#FFFFFF",
        textMutedColor: "#9CA3AF"
      },
      features: [
        { iconName: "Wallet", title: "Smart Wallet", desc: "Access premium tools and direct asset transfers instantly." },
        { iconName: "TrendingUp", title: "Live Insights", desc: "Understand your operational bottlenecks at a glance." }
      ],
      appUI: {
        screenTitle: "Analytics",
        screenBalance: "$24,510.50",
        chartData: [40, 20, 60, 45, 80, 70, 95],
        theme: "dark",
        items: [
          { label: "Weekly Growth", value: "+12.4%", icon: "TrendingUp", color: "#10B981" },
          { label: "Cloud Node", value: "Secure", icon: "Cloud", color: "#3B82F6" }
        ]
      },
      promptDescription: "An editorial style layout featuring sharp serif style high-contrast blocks, premium card components, and vibrant amber spotlights."
    },
    {
      layoutType: "feature-grid",
      title: "MEET THE NEW GOLD STANDARD.",
      subtitle: `Experience ${name}, designed to redefine premium standards with customized analytics and gorgeous visual panels.`,
      badgeText: "VERSION 4.0 ACTIVE",
      colors: {
        bgGradientType: "radial",
        bgColors: ["#0B0D19", "#04050A"], // Deep cosmic blue
        accentColor: "#EC4899", // Neon pink
        textColor: "#FFFFFF",
        textMutedColor: "#94A3B8"
      },
      features: [
        { iconName: "Target", title: "Targeted Goals", desc: "Set automatic metrics and watch your efficiency climb." },
        { iconName: "Compass", title: "Explore Tools", desc: "Unlock endless modules tailored specifically to you." }
      ],
      appUI: {
        screenTitle: "My Goal",
        screenBalance: "82% Complete",
        chartData: [10, 40, 30, 65, 50, 85, 100],
        theme: "dark",
        items: [
          { label: "Completed Steps", value: "41/50", icon: "Star", color: "#EC4899" },
          { label: "Daily Streaks", value: "12 Days", icon: "Flame", color: "#FF3B30" }
        ]
      },
      promptDescription: "A dark high-fidelity neon cyber-punk style poster with deep cosmic violet gradients and glowing pink elements."
    }
  ];
}

// REST API for poster generation
app.post("/api/generate", async (req, res) => {
  const { appName, appCategory, prompt, themeStyle, aiEngine } = req.body;

  if (!appName) {
    return res.status(400).json({ error: "App Name is required." });
  }

  const promptInstructions = `
    You are a world-class creative director and UI/UX advertising designer.
    Generate 3 distinct, highly professional, premium app advertisement poster design variations based on these inputs:
    - App Name: "${appName}"
    - Category/Niche: "${appCategory || "General Utility"}"
    - User Prompt / Design Request: "${prompt || "Modern premium advertisement poster"}"
    - Preferred Theme Style: "${themeStyle || "Modern Minimalist"}"

    For each of the 3 variations, return full visual layout instructions in the specified JSON schema.
    Make sure to invent catchy, extremely high-quality headlines (titles) and subheadlines (subtitles) tailored to the app name and user request.
    
    Variation themes should differ:
    - Variation 1: Clean/Minimalist, using bold typography, large whitespace, and the brand color palette (suggest beautiful gradients).
    - Variation 2: Feature-heavy, showing off specific features and lists with catchy descriptions.
    - Variation 3: Premium Editorial / Futuristic, with rich contrasting color tones, dramatic highlights, and structured badges.

    Icons to use should be standard Lucide icons: "Wallet", "TrendingUp", "Shield", "Zap", "Star", "Target", "Compass", "Flame", "Activity", "Check", "Cloud", "ArrowUpRight", "ArrowDownLeft", "Bell", "Settings", "Cpu".
    
    Ensure color schemes contain hex codes that look incredible together (avoid generic colors, prefer premium dark backgrounds, sophisticated pastel tones, neon high-contrast accents).
  `;

  // Handle OpenAI (ChatGPT) engine
  if (aiEngine === "openai") {
    try {
      console.log("Calling OpenAI GPT-4o-mini for poster generation...");
      const openAIKey = process.env.OPENAI_API_KEY || DEFAULT_OPENAI_KEY;
      
      const openAIResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${openAIKey}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: "You are a world-class creative director and UI/UX advertising designer. You must return ONLY a valid, raw JSON object matching the requested schema with no markdown formatting tags. The root key MUST be \"posters\" containing an array of 3 poster variation objects, each containing: layoutType, title, subtitle, badgeText, colors, features, appUI, promptDescription."
            },
            {
              role: "user",
              content: promptInstructions
            }
          ],
          response_format: { type: "json_object" },
          temperature: 0.7
        })
      });

      if (!openAIResponse.ok) {
        const errorText = await openAIResponse.text();
        throw new Error(`OpenAI API returned status ${openAIResponse.status}: ${errorText}`);
      }

      const responseData = await openAIResponse.json();
      const rawText = responseData.choices?.[0]?.message?.content;
      if (!rawText) {
        throw new Error("Empty response from OpenAI chat completion.");
      }

      const parsedData = JSON.parse(rawText.trim());
      if (parsedData && parsedData.posters) {
        return res.json(parsedData);
      } else {
        throw new Error("OpenAI response is missing the 'posters' array.");
      }
    } catch (openaiErr: any) {
      console.error("OpenAI Generation Error, falling back to Gemini:", openaiErr);
      // Fall through to Gemini as automatic high-fidelity backup
    }
  }

  // Handle Gemini engine (Default)
  try {
    const ai = getGeminiClient();
    
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: promptInstructions,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["posters"],
          properties: {
            posters: {
              type: Type.ARRAY,
              description: "Array of 3 distinct poster variations",
              items: {
                type: Type.OBJECT,
                required: ["layoutType", "title", "subtitle", "badgeText", "colors", "features", "appUI", "promptDescription"],
                properties: {
                  layoutType: {
                    type: Type.STRING,
                    description: "Layout style: 'hero-showcase', 'minimal-editorial', 'feature-grid', 'split-promo', or 'circular-bento'"
                  },
                  title: {
                    type: Type.STRING,
                    description: "Catchy bold uppercase poster headline (6 to 12 words max)"
                  },
                  subtitle: {
                    type: Type.STRING,
                    description: "Descriptive premium body copy/subheadline (15 to 30 words max)"
                  },
                  badgeText: {
                    type: Type.STRING,
                    description: "A small pill-shaped label or award badge (e.g., 'RATED 4.9★ BY EDITORS')"
                  },
                  colors: {
                    type: Type.OBJECT,
                    required: ["bgGradientType", "bgColors", "accentColor", "textColor", "textMutedColor"],
                    properties: {
                      bgGradientType: {
                        type: Type.STRING,
                        description: "Gradient pattern: 'linear' or 'radial'"
                      },
                      bgColors: {
                        type: Type.ARRAY,
                        description: "Array of 2-3 hex colors for background gradient",
                        items: { type: Type.STRING }
                      },
                      accentColor: {
                        type: Type.STRING,
                        description: "Pistachio, lime, neon orange, or electric blue accent hex color"
                      },
                      textColor: {
                        type: Type.STRING,
                        description: "Primary text hex color, e.g., #FFFFFF"
                      },
                      textMutedColor: {
                        type: Type.STRING,
                        description: "Muted/subtle text hex color, e.g., #94A3B8"
                      }
                    }
                  },
                  features: {
                    type: Type.ARRAY,
                    description: "Array of exactly 2 prominent features",
                    items: {
                      type: Type.OBJECT,
                      required: ["iconName", "title", "desc"],
                      properties: {
                        iconName: { type: Type.STRING, description: "Lucide icon name (e.g. Shield, Zap, TrendingUp)" },
                        title: { type: Type.STRING, description: "Feature title (2-4 words)" },
                        desc: { type: Type.STRING, description: "Feature description (6-12 words)" }
                      }
                    }
                  },
                  appUI: {
                    type: Type.OBJECT,
                    required: ["screenTitle", "screenBalance", "chartData", "theme", "items"],
                    properties: {
                      screenTitle: { type: Type.STRING, description: "Name of active view inside simulated app screen" },
                      screenBalance: { type: Type.STRING, description: "Main primary value shown in app, e.g., '$14,230.12' or '94% Safe'" },
                      chartData: {
                        type: Type.ARRAY,
                        description: "Array of 7 numerical values representing a dynamic chart line",
                        items: { type: Type.INTEGER }
                      },
                      theme: { type: Type.STRING, description: "'dark' or 'light'" },
                      items: {
                        type: Type.ARRAY,
                        description: "Exactly 2 detailed action item or summary list rows",
                        items: {
                          type: Type.OBJECT,
                          required: ["label", "value", "icon", "color"],
                          properties: {
                            label: { type: Type.STRING, description: "Row label, e.g. 'Instant Yield'" },
                            value: { type: Type.STRING, description: "Row value, e.g. '12.4% APY' or 'Active'" },
                            icon: { type: Type.STRING, description: "Lucide icon name (e.g. Activity, Check, Cloud)" },
                            color: { type: Type.STRING, description: "Row accent hex color" }
                          }
                        }
                      }
                    }
                  },
                  promptDescription: {
                    type: Type.STRING,
                    description: "A short, professional sentence explaining why this visual design composition fits the user's prompt."
                  }
                }
              }
            }
          }
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response received from Gemini.");
    }

    const data = JSON.parse(resultText);
    res.json(data);
  } catch (error: any) {
    console.error("Gemini Poster Generation Error:", error);
    // Fallback gracefully so the app stays perfectly operational
    const mockVariations = getMockPosterVariations(appName, appCategory, prompt, themeStyle);
    res.json({ posters: mockVariations, warning: "Using creative fallback because API limit reached." });
  }
});

// REST API for Gemini custom vector asset image generation
app.post("/api/generate-image", async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: "Prompt is required." });
  }

  try {
    console.log(`Generating visual asset via Gemini for prompt: "${prompt}"`);
    const ai = getGeminiClient();
    
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [
          {
            text: `High fidelity modern mobile app screen visualization, flat digital dashboard UI mockup, premium professional graphic asset: ${prompt}`
          }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    let base64Image = "";
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          base64Image = part.inlineData.data;
          break;
        }
      }
    }

    if (base64Image) {
      return res.json({ imageUrl: `data:image/png;base64,${base64Image}` });
    } else {
      throw new Error("No image data found in response parts.");
    }
  } catch (err: any) {
    console.error("Gemini Image generation error:", err);
    
    const pLower = prompt.toLowerCase();
    
    // Categorize based on keywords to match user intent perfectly
    let fallbacks = [
      "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=600&auto=format&fit=crop&q=80",
      "https://images.unsplash.com/photo-1618005198143-d3668f3b2856?w=600&auto=format&fit=crop&q=80"
    ];

    if (pLower.includes("apple") || pLower.includes("ios") || pLower.includes("minimal")) {
      fallbacks = [
        "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=600&auto=format&fit=crop&q=80", // sleek metallic macbook/apple vibes
        "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=600&auto=format&fit=crop&q=80", // modern tech design setup
        "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=600&auto=format&fit=crop&q=80"  // clean hardware arrangement
      ];
    } else if (pLower.includes("cyberpunk") || pLower.includes("neon") || pLower.includes("synthwave")) {
      fallbacks = [
        "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=600&auto=format&fit=crop&q=80", // neon city structures
        "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&auto=format&fit=crop&q=80", // cyberpunk anime tech neon
        "https://images.unsplash.com/photo-1515260268569-9271009adfdb?w=600&auto=format&fit=crop&q=80"  // sleek violet neon lines
      ];
    } else if (pLower.includes("pastel") || pLower.includes("papercut") || pLower.includes("geometric")) {
      fallbacks = [
        "https://images.unsplash.com/photo-1557683316-973673baf926?w=600&auto=format&fit=crop&q=80", // soft pastel pink gradient
        "https://images.unsplash.com/photo-1618005198143-d3668f3b2856?w=600&auto=format&fit=crop&q=80", // organic modern pastel shape
        "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?w=600&auto=format&fit=crop&q=80"  // beautiful monochrome smooth papers
      ];
    } else if (pLower.includes("crypto") || pLower.includes("bitcoin") || pLower.includes("coin") || pLower.includes("glossy")) {
      fallbacks = [
        "https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=600&auto=format&fit=crop&q=80", // glowing golden coins
        "https://images.unsplash.com/photo-1640340434855-6084b1f4901c?w=600&auto=format&fit=crop&q=80", // decentralized block connection
        "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&auto=format&fit=crop&q=80"  // glossy crypto digital render
      ];
    } else if (pLower.includes("teal") || pLower.includes("fintech") || pLower.includes("analytics") || pLower.includes("dashboard")) {
      fallbacks = [
        "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&auto=format&fit=crop&q=80", // elegant tech data dashboard graph
        "https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=600&auto=format&fit=crop&q=80", // clean cyan analytics visualization
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80"  // business dashboard tech mockup
      ];
    }

    // Determine variation index cleanly using prompt identifiers style A, B, or C
    let idx = 0;
    if (pLower.includes("style b") || pLower.includes("variation style b") || pLower.includes("pipeline b")) {
      idx = 1 % fallbacks.length;
    } else if (pLower.includes("style c") || pLower.includes("variation style c") || pLower.includes("pipeline c")) {
      idx = 2 % fallbacks.length;
    } else {
      idx = prompt.length % fallbacks.length;
    }

    const pickedUrl = fallbacks[idx];
    res.json({ 
      imageUrl: pickedUrl,
      warning: "Returned customized high-fidelity visual design fallback due to API limits."
    });
  }
});

// Configure Vite or Static Assets
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
